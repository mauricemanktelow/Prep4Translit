﻿using System;
using System.Globalization;
using mm.ConstantsSpecifications;

namespace mm.Extensions
{
    /// <summary>
    /// 
    /// </summary>
    public static class CharExtensions
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static string ConvertCharacterToHexAsString(this Char aChar)
        {
            int value = Convert.ToInt32(aChar);
            return String.Format("{0:X}", value).PadLeft(4, '0');
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static bool IsCharacterADiacritic(this Char aChar)
        {
            bool isNonSpacingMark = CharUnicodeInfo.GetUnicodeCategory(aChar) == UnicodeCategory.NonSpacingMark;
            bool isSpacingCombiningMark = CharUnicodeInfo.GetUnicodeCategory(aChar) == UnicodeCategory.SpacingCombiningMark;
            bool result = isNonSpacingMark || isSpacingCombiningMark;
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static bool IsCharacterAHyphen(this Char aChar)
        {
            bool result = false;
            if (aChar != '?')
            {
                string allHyphens = Constants.AllHyphensAndDashes;
                result = allHyphens.Contains(aChar.ToString());
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static bool IsLetterOrDigitOrSpace(this Char aChar)
        {
            return Char.IsLetter(aChar) || Char.IsDigit(aChar) || Char.IsWhiteSpace(aChar);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static bool IsLetterOrPunctuation(this Char aChar)
        {
            return Char.IsLetter(aChar) || Char.IsPunctuation(aChar);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static bool IsSpace(this Char aChar)
        {
            return aChar == ' ';
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static bool IsNewLine(this Char aChar)
        {
            return aChar == '\n' || aChar == '\r';
        }

        /// <summary>
        /// Checks if a character is in the ascii range 0-127
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static bool IsCharacterInAsciiRange(this char aChar)
        {
            return ((int)aChar) < 128;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static string EnglishName(char aChar)
        {
            string name = "";
            switch ((int)aChar)
            {
                case 0: name = "Null character"; break;
                case 1: name = "Start of Heading"; break;
                case 2: name = "Start of Text"; break;
                case 3: name = "End-of-text character"; break;
                case 4: name = "End-of-transmission character"; break;
                case 5: name = "Enquiry character"; break;
                case 6: name = "Acknowledge character"; break;
                case 7: name = "Bell character"; break;
                case 8: name = "Backspace"; break;
                case 9: name = "Horizontal tab"; break;
                case 10: name = "Line feed"; break;
                case 11: name = "Vertical tab"; break;
                case 12: name = "Form feed"; break;
                case 13: name = "Carriage return"; break;
                case 14: name = "Shift Out"; break;
                case 15: name = "Shift In"; break;
                case 16: name = "Data Link Escape"; break;
                case 17: name = "Device Control 1"; break;
                case 18: name = "Device Control 2"; break;
                case 19: name = "Device Control 3"; break;
                case 20: name = "Device Control 4"; break;
                case 21: name = "Negative-acknowledge character"; break;
                case 22: name = "Synchronous Idle"; break;
                case 23: name = "End of Transmission Block"; break;
                case 24: name = "Cancel character"; break;
                case 25: name = "End of Medium"; break;
                case 26: name = "Substitute character"; break;
                case 27: name = "Escape character"; break;
                case 28: name = "File Separator"; break;
                case 29: name = "Group Separator"; break;
                case 30: name = "Record Separator"; break;
                case 31: name = "Unit Separator"; break;
                case 32: name = "Space"; break;
                case 33: name = "Exclamation mark"; break;
                case 34: name = "Quotation mark"; break;
                case 35: name = "Number sign"; break;
                case 36: name = "Dollar sign"; break;
                case 37: name = "Percent sign"; break;
                case 38: name = "Ampersand"; break;
                case 39: name = "Apostrophe"; break;
                case 40: name = "Left parenthesis"; break;
                case 41: name = "Right parenthesis"; break;
                case 42: name = "Asterisk"; break;
                case 43: name = "Plus sign"; break;
                case 44: name = "Comma"; break;
                case 45: name = "Ambiguous Hyphen-minus"; break;
                case 46: name = "Full stop"; break;
                case 47: name = "Slash"; break;
                case 48: name = "Digit Zero"; break;
                case 49: name = "Digit One"; break;
                case 50: name = "Digit Two"; break;
                case 51: name = "Digit Three"; break;
                case 52: name = "Digit Four"; break;
                case 53: name = "Digit Five"; break;
                case 54: name = "Digit Six"; break;
                case 55: name = "Digit Seven"; break;
                case 56: name = "Digit Eight"; break;
                case 57: name = "Digit Nine"; break;
                case 58: name = "Colon"; break;
                case 59: name = "Semicolon"; break;
                case 60: name = "Less-than sign"; break;
                case 61: name = "Equal sign"; break;
                case 62: name = "Greater-than sign"; break;
                case 63: name = "Question mark"; break;
                case 64: name = "At sign"; break;
                case 65: name = "Latin Capital letter A"; break;
                case 66: name = "Latin Capital letter B"; break;
                case 67: name = "Latin Capital letter C"; break;
                case 68: name = "Latin Capital letter D"; break;
                case 69: name = "Latin Capital letter E"; break;
                case 70: name = "Latin Capital letter F"; break;
                case 71: name = "Latin Capital letter G"; break;
                case 72: name = "Latin Capital letter H"; break;
                case 73: name = "Latin Capital letter I"; break;
                case 74: name = "Latin Capital letter J"; break;
                case 75: name = "Latin Capital letter K"; break;
                case 76: name = "Latin Capital letter L"; break;
                case 77: name = "Latin Capital letter M"; break;
                case 78: name = "Latin Capital letter N"; break;
                case 79: name = "Latin Capital letter O"; break;
                case 80: name = "Latin Capital letter P"; break;
                case 81: name = "Latin Capital letter Q"; break;
                case 82: name = "Latin Capital letter R"; break;
                case 83: name = "Latin Capital letter S"; break;
                case 84: name = "Latin Capital letter T"; break;
                case 85: name = "Latin Capital letter U"; break;
                case 86: name = "Latin Capital letter V"; break;
                case 87: name = "Latin Capital letter W"; break;
                case 88: name = "Latin Capital letter X"; break;
                case 89: name = "Latin Capital letter Y"; break;
                case 90: name = "Latin Capital letter Z"; break;
                case 91: name = "Left Square Bracket"; break;
                case 92: name = "Backslash"; break;
                case 93: name = "Right Square Bracket"; break;
                case 94: name = "Circumflex accent"; break;
                case 95: name = "Low line"; break;
                case 96: name = "Grave accent"; break;
                case 97: name = "Latin Small Letter A"; break;
                case 98: name = "Latin Small Letter B"; break;
                case 99: name = "Latin Small Letter C"; break;
                case 100: name = "Latin Small Letter D"; break;
                case 101: name = "Latin Small Letter E"; break;
                case 102: name = "Latin Small Letter F"; break;
                case 103: name = "Latin Small Letter G"; break;
                case 104: name = "Latin Small Letter H"; break;
                case 105: name = "Latin Small Letter I"; break;
                case 106: name = "Latin Small Letter J"; break;
                case 107: name = "Latin Small Letter K"; break;
                case 108: name = "Latin Small Letter L"; break;
                case 109: name = "Latin Small Letter M"; break;
                case 110: name = "Latin Small Letter N"; break;
                case 111: name = "Latin Small Letter O"; break;
                case 112: name = "Latin Small Letter P"; break;
                case 113: name = "Latin Small Letter Q"; break;
                case 114: name = "Latin Small Letter R"; break;
                case 115: name = "Latin Small Letter S"; break;
                case 116: name = "Latin Small Letter T"; break;
                case 117: name = "Latin Small Letter U"; break;
                case 118: name = "Latin Small Letter V"; break;
                case 119: name = "Latin Small Letter W"; break;
                case 120: name = "Latin Small Letter X"; break;
                case 121: name = "Latin Small Letter Y"; break;
                case 122: name = "Latin Small Letter Z"; break;
                case 123: name = "Left Curly Bracket"; break;
                case 124: name = "Vertical bar"; break;
                case 125: name = "Right Curly Bracket"; break;
                case 126: name = "Tilde"; break;
                case 127: name = "Delete"; break;
                case 160: name = "Non-breaking space"; break;
                case 8194: name = "En space"; break;
                case 8195: name = "Em space"; break;
                case 8202: name = "Hair space"; break;
                case 8209: name = "Non-breaking hyphen"; break;
                case 8210: name = "Figure Dash/Unambiguous hyphen"; break;
                case 8211: name = "En Dash"; break;
                case 8212: name = "Em Dash"; break;
                case 8213: name = "Horizontal bar"; break;
                case 8214: name = "Double vertical line"; break;
                case 8216: name = "Single opening quotation mark"; break;
                case 8217: name = "Single closing quotation mark"; break;
                case 8220: name = "Double opening quotation mark"; break;
                case 8221: name = "Double closing quotation mark"; break;
                case 8272: name = "Minus sign"; break;
            }
            return name;
        }
    }
}
