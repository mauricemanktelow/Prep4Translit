﻿using System;
using System.IO;

namespace mm.Extensions
{

    public static class DirectoryExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dir"></param>
        /// <returns></returns>
        public static bool CanCreateFileInDirectory(this DirectoryInfo directoryInfo)
        {
            bool canCreate = true;
            if (string.IsNullOrWhiteSpace(directoryInfo.FullName))
            {
                canCreate = false;
            }
            else
            {
                string tempFileName = Path.Combine(directoryInfo.FullName, Guid.NewGuid().ToString() + ".tmp");
                if (Directory.Exists(directoryInfo.FullName) == false)
                    Directory.CreateDirectory(directoryInfo.FullName);
                try
                {
                    using (File.Create(tempFileName)) { }
                    File.Delete(tempFileName);
                }
                catch
                {
                    canCreate = false;
                }
            }
            return canCreate;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="dirInfo"></param>
        /// <param name="name"></param>
        public static void RenameTo(this DirectoryInfo dirInfo, string name)
        {
            if (dirInfo == null)
            {
                throw new ArgumentNullException("dirInfo", "Directory info to rename cannot be null");
            }

            if (string.IsNullOrEmpty(name.Trim()))
            {
                throw new ArgumentException("New name cannot be null or blank", "name");
            }

            dirInfo.MoveTo(Path.Combine(dirInfo.Parent.FullName, name));

            return;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceDirName"></param>
        /// <param name="destDirName"></param>
        /// <param name="copySubDirs"></param>
        public static void Copy(this DirectoryInfo dir, string destDirName, bool copySubDirs)
        {

            if (!dir.Exists)
            {
                throw new DirectoryNotFoundException(
                    "Source directory does not exist or could not be found: "
                    + dir.Name);
            }

            CopyNow(dir, destDirName, copySubDirs);
        }

        private static void CopyNow(this DirectoryInfo dir, string destDirName, bool copySubDirs)
        {

            DirectoryInfo[] dirs = dir.GetDirectories();
            // If the destination directory doesn't exist, create it.
            if (!Directory.Exists(destDirName))
            {
                Directory.CreateDirectory(destDirName);
            }

            // Get the files in the directory and copy them to the new location.
            FileInfo[] files = dir.GetFiles();
            foreach (FileInfo file in files)
            {
                string temppath = Path.Combine(destDirName, file.Name);
                file.CopyTo(temppath, false);
            }

            // If copying subdirectories, copy them and their contents to new location.
            if (copySubDirs)
            {
                foreach (DirectoryInfo subdir in dirs)
                {
                    string temppath = Path.Combine(destDirName, subdir.Name);
                    CopyNow(subdir, temppath, copySubDirs);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="directoryInfo"></param>
        /// <returns></returns>
        public static bool IsReadOnly(this DirectoryInfo directoryInfo)
        {
            return directoryInfo.Attributes.HasFlag(FileAttributes.ReadOnly);
        }

        public static void SetAttribute(this DirectoryInfo directoryInfo, FileAttributes fileAttributes)
        {
            directoryInfo.Attributes &= ~fileAttributes;
        }
    }
}
