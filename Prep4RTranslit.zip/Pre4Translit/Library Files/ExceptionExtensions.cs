﻿using System;
using System.Text;

namespace mm.Extensions
{
    public static class ExceptionExtension
    {
        public static string ErrorMessageIncludingInnerExceptionMessage(this Exception err)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Error message: " + err.Message);
            sb.AppendLine("");
            while (err != null)
            {
                sb.AppendLine("Inner exception:" + err.Message);
                err = err.InnerException;
            }
            return sb.ToString();
        }
    }
}
