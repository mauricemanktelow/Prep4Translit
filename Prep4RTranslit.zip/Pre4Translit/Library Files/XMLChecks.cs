﻿using System.Xml;


namespace mm.Utilities
{
    /// <summary>
    /// Check the XML is well-formed
    /// </summary>
    public class XMLChecks
    {
        public static bool IsWellFormedXML(string xmlStr)
        {
            bool xmlStrIsWellFormed = true;
            try
            {
                if (!string.IsNullOrEmpty(xmlStr))
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(xmlStr);
                }
                else
                {
                    xmlStrIsWellFormed =  false;
                }
            }
            catch (XmlException)
            {
                xmlStrIsWellFormed = false;
            }
            return xmlStrIsWellFormed;
        }
    }
}
