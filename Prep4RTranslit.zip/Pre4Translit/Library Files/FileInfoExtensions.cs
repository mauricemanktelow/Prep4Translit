﻿using System;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Net;
using mm.Utilities;




namespace mm.Extensions
{
    /// <summary>
    /// 
    /// </summary>
    public static class FileInfoExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        public enum FileWasDownloadedAndSavedResult
        {
            FileDoesNotExist,
            FileSuccessfullyDownloadedAndSaved,
            CouldNotDownloadFile_NoInternetConnection,
            CannotWriteToDestination,
            ErrorTryingToDownloadFile,
            TextObtained
        }

        /// <summary>
        /// 
        /// </summary>
        public enum CanSaveFileResults
        {
            FileNameIsEmpty,
            FileAlreadyExistsAndIsNotReadOnly,
            FileAlreadyExistsAndIsReadOnly,
            FileDoesNotExistAndDirectoryIsNotReadOnly,
            FileDoesNotExistAndDirectoryIsReadOnly,
            FileDoesNotExistAndCanCreateDirectory,
            FileDoesNotExistAndCannotCreateDirectory
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="attributes"></param>
        /// <param name="attributesToRemove"></param>
        /// <returns></returns>
        public static FileAttributes RemoveAttribute(FileAttributes attributes, FileAttributes attributesToRemove)
        {
            return attributes & ~attributesToRemove;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static CanSaveFileResults CanSaveFile(this FileInfo fileInfo)
        {
            CanSaveFileResults result = CanSaveFileResults.FileNameIsEmpty;

            if (fileInfo.Exists)
            {
                if (fileInfo.IsReadOnly)
                    result = CanSaveFileResults.FileAlreadyExistsAndIsReadOnly;
                else
                    result = CanSaveFileResults.FileAlreadyExistsAndIsNotReadOnly;
            }
            else
            {
                string directory = fileInfo.DirectoryName;
                DirectoryInfo directoryInfo = new DirectoryInfo(fileInfo.DirectoryName);
                if (directoryInfo.Exists)
                {
                    if ((directoryInfo.Attributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
                        result = CanSaveFileResults.FileDoesNotExistAndDirectoryIsReadOnly;
                    else
                        result = CanSaveFileResults.FileDoesNotExistAndDirectoryIsNotReadOnly;
                }
                else
                {
                    try
                    {
                        result = CanSaveFileResults.FileDoesNotExistAndCanCreateDirectory;
                    }
                    catch
                    {
                        result = CanSaveFileResults.FileDoesNotExistAndCannotCreateDirectory;
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Set file attributes
        /// </summary>
        /// <param name="fileName">File whose attributes are to be set</param>
        /// <param name="setToReadOnly">Read/write status required</param>
        public static bool SetFileReadWriteAttributeReadOnly(this FileInfo fileInfo, Boolean setToReadOnly)
        {
            bool result = true;
            try
            {
                if (fileInfo.Exists)
                {
                    FileAttributes currAttr = File.GetAttributes(fileInfo.FullName);
                    if (fileInfo.IsReadOnly)
                    {// Current file is Read only
                        if (!setToReadOnly)
                        {// Remove ReadOnly
                            currAttr = currAttr & ~FileAttributes.ReadOnly;
                            File.SetAttributes(fileInfo.FullName, currAttr);
                        }
                    }
                    else
                    {// Current file is not Read only
                        if (setToReadOnly)
                        {// Set to ReadOnlu
                            currAttr = currAttr | FileAttributes.ReadOnly;
                            File.SetAttributes(fileInfo.FullName, currAttr);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Error encountered when trying to reset file attributes");
                sb.AppendLine("File: " + fileInfo.FullName);
                if (setToReadOnly)
                    sb.AppendLine("Attempted to set attribute to Read Only");
                else
                    sb.AppendLine("Attempted to remove attribute Read Only");
                sb.AppendLine("");
                sb.AppendLine("Error message: " + err.Message);
                MessageBox.Show(sb.ToString());
                result = false;
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceFileURI"></param>
        /// <param name="downloadDestinationFilename"></param>
        /// <param name="okToOverwriteExistingFile"></param>
        /// <returns></returns>
        public static FileWasDownloadedAndSavedResult DownloadFileFromInternet(string sourceFileURI, string downloadDestinationFilename, bool okToOverwriteExistingFile)
        {
            FileWasDownloadedAndSavedResult fileDownloadedSuccessfully = FileWasDownloadedAndSavedResult.ErrorTryingToDownloadFile;
            sourceFileURI = sourceFileURI.Trim();
            downloadDestinationFilename = downloadDestinationFilename.Trim();
            if (ParamaterCheck(sourceFileURI, downloadDestinationFilename))
            {
                try
                {
                    if (OnlineConnection.CanConnectOnLine())
                    {
                            if (CheckCanWriteToDestination(downloadDestinationFilename, okToOverwriteExistingFile))
                            {
                                WebClient webClient = new WebClient();
                                webClient.DownloadFile(sourceFileURI, downloadDestinationFilename);
                                fileDownloadedSuccessfully = FileWasDownloadedAndSavedResult.FileSuccessfullyDownloadedAndSaved;
                            }
                            else
                                fileDownloadedSuccessfully = FileWasDownloadedAndSavedResult.CannotWriteToDestination;
                    }
                    else
                        fileDownloadedSuccessfully = FileWasDownloadedAndSavedResult.CouldNotDownloadFile_NoInternetConnection;
                }
                catch (Exception err)
                {
                    if (err.Message.Contains("404"))
                        fileDownloadedSuccessfully = FileWasDownloadedAndSavedResult.FileDoesNotExist;
                    else
                    { 
                        StringBuilder sb = new StringBuilder();
                        sb.AppendLine("Error trying to download file");
                        sb.AppendLine("      " + sourceFileURI);
                        sb.AppendLine("");
                        sb.AppendLine("Saving to");
                        sb.AppendLine("      " + downloadDestinationFilename);
                        sb.AppendLine("");
                        sb.AppendLine(err.ErrorMessageIncludingInnerExceptionMessage());
                        MessageBox.Show(sb.ToString(), "Error");
                        fileDownloadedSuccessfully = FileWasDownloadedAndSavedResult.ErrorTryingToDownloadFile;
                    }
                }
            }
            return fileDownloadedSuccessfully;
        }
    

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceFileURI"></param>
        /// <param name="downloadDestinationFilename"></param>
        /// <param name="fileText"></param>
        /// <returns></returns>
        public static FileWasDownloadedAndSavedResult ReadTextFileFromInternet(this FileInfo fileInfo, string sourceFileURI, string downloadDestinationFilename, out string fileText)
        {
            string connectionMessage = "";
            fileText = null;
            FileWasDownloadedAndSavedResult textReadSuccessfully = FileWasDownloadedAndSavedResult.ErrorTryingToDownloadFile;
            sourceFileURI = sourceFileURI.Trim();
            downloadDestinationFilename = downloadDestinationFilename.Trim();
            if (ParamaterCheck(sourceFileURI, downloadDestinationFilename))
            {
                try
                {
                    if (OnlineConnection.CanConnectOnLine(out connectionMessage))
                    {
                        WebClient webClient = new WebClient();
                        textReadSuccessfully = FileWasDownloadedAndSavedResult.FileSuccessfullyDownloadedAndSaved;
                        Stream data = webClient.OpenRead(sourceFileURI);
                        using (StreamReader reader = new StreamReader(data))
                        {
                            fileText = reader.ReadToEnd();
                            textReadSuccessfully = FileWasDownloadedAndSavedResult.TextObtained;
                        }
                    }
                    else
                        textReadSuccessfully = FileWasDownloadedAndSavedResult.CouldNotDownloadFile_NoInternetConnection;
                    if (String.IsNullOrWhiteSpace(connectionMessage.Trim()) == false)
                        connectionMessage = Environment.NewLine + connectionMessage;
                }
                catch (Exception err)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("Error trying to download file " + sourceFileURI);
                    sb.AppendLine();
                    sb.AppendLine("Connection message: " + connectionMessage);
                    sb.AppendLine();
                    sb.AppendLine("Error message: " + err.ErrorMessageIncludingInnerExceptionMessage());
                    MessageBox.Show(sb.ToString(), "Error");
                    textReadSuccessfully = FileWasDownloadedAndSavedResult.ErrorTryingToDownloadFile;
                }
            }
            if(String.IsNullOrWhiteSpace(connectionMessage.Trim()) == false)
                MessageBox.Show("Connection message:  " + connectionMessage, "Information");
            return textReadSuccessfully;
        }

        private static bool ParamaterCheck(string source, string destination)
        {
            bool result = true;
            if (String.IsNullOrEmpty(source))
                MessageBox.Show("Error in ReadTextFileFromInternet: - No URL specified.");
            if (String.IsNullOrEmpty(destination))
                MessageBox.Show("Error in ReadTextFileFromInternet: - No designation file specified.");
            return result;
        }

        private static bool CheckCanWriteToDestination(string filename, bool okToOverwriteExistingFile)
        {
            bool checkResult = false;
            FileInfo fileInfo = new FileInfo(filename);
            if (fileInfo.Exists)
            {
                if (okToOverwriteExistingFile)
                {
                    try
                    {
                        fileInfo.Delete();
                        checkResult = true;
                    }
                    catch (Exception err)
                    {
                        string s = err.Message;
                        checkResult = false;
                    }
                }
                else
                    checkResult = false;
            }
            else
            {
                string directory = fileInfo.DirectoryName;
                DirectoryInfo directoryInfo = new DirectoryInfo(directory);
                if (directoryInfo.Exists)
                {
                    checkResult = !directoryInfo.Attributes.HasFlag(FileAttributes.ReadOnly);
                }
                else
                {
                    try
                    {
                        directoryInfo.Create();
                        checkResult = true;
                    }
                    catch (Exception err)
                    {
                        string s = err.Message;
                        checkResult = false;
                    }
                }
            }
            return checkResult;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileInfo"></param>
        /// <param name="rename"></param>
        public static void RenameFile(string originalName, string newName)
        {
            if (File.Exists(originalName))
            {
                if (string.IsNullOrEmpty(newName.Trim()))
                {
                    throw new ArgumentException("Cannot rename file - new name cannot be null or blank");
                }
                else
                if (File.Exists(newName))
                    throw new ArgumentException("Cannot rename file - a file with this name already exists");
                else
                {
                    try
                    {
                        string newFilePath = Path.GetDirectoryName(newName);
                        if (Directory.Exists(newFilePath) == false)
                            Directory.CreateDirectory(newFilePath);
                        File.Move(originalName, newName);
                    }
                    catch(Exception err)
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.AppendLine("Error encountered when renaming file");
                        sb.AppendLine("");
                        sb.AppendLine("Original file name: " + originalName);
                        sb.AppendLine("New file name: " + newName);
                        sb.AppendLine("");
                        sb.AppendLine(err.Message);
                        while (err != null)
                        {
                            err = err.InnerException;
                            sb.AppendLine(err.Message);
                        }
                        MessageBox.Show(sb.ToString(), "Error");
                    }
                }
            }
            else
                throw new ArgumentNullException("fileInfo", "File " + originalName + " cannot be renamed - it does not exist");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="absolutepath">The path to compress</param>
        /// <param name="limit">The maximum length</param>
        /// <param name="delimiter">The character(s) to use to imply incompleteness</param>
        /// <returns></returns>
        public static string ShrinkPath(this FileInfo fileInfo, int limit, string delimiter = "…")
        {
            //no path provided
            if (string.IsNullOrEmpty(fileInfo.FullName))
            {
                return "";
            }

            var name = Path.GetFileName(fileInfo.FullName);
            int namelen = name.Length;
            int pathlen = fileInfo.FullName.Length;
            var dir = fileInfo.FullName.Substring(0, pathlen - namelen);

            int delimlen = delimiter.Length;
            int idealminlen = namelen + delimlen;

            var slash = (fileInfo.FullName.IndexOf("/") > -1 ? "/" : "\\");

            //less than the minimum amt
            if (limit < ((2 * delimlen) + 1))
            {
                return "";
            }

            //fullpath
            if (limit >= pathlen)
            {
                return fileInfo.FullName;
            }

            //file name condensing
            if (limit < idealminlen)
            {
                return delimiter + name.Substring(0, (limit - (2 * delimlen))) + delimiter;
            }

            //whole name only, no folder structure shown
            if (limit == idealminlen)
            {
                return delimiter + name;
            }
            return dir.Substring(0, (limit - (idealminlen + 1))) + delimiter + slash + name;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileInfo1"></param>
        /// <param name="fileInfo2"></param>
        /// <returns></returns>
        public static bool IsFileEqualToAnotherOne(this FileInfo fileInfo1, FileInfo fileInfo2)
        {
            bool filesAreEqual = true;
            try
            {
                byte[] file1 = File.ReadAllBytes(fileInfo1.FullName);
                byte[] file2 = File.ReadAllBytes(fileInfo2.FullName);
                if (file1.Length == file2.Length)
                {
                    for (int i = 0; i < file1.Length; i++)
                    {
                        if (file1[i] != file2[i])
                        {
                            filesAreEqual = false;
                            break;
                        }
                    }
                }
                else
                    filesAreEqual = false;
            }
            catch (Exception)
            {
                filesAreEqual = false;
            }
            return filesAreEqual;
        }
    }
}
