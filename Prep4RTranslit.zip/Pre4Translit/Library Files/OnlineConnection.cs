﻿using System;
using System.Net.NetworkInformation;
using System.Text;
using System.Net;
using mm.Extensions;
using System.Runtime.InteropServices;


namespace mm.Utilities
{

    public static class InternetCS
    {
        //Creating the extern function...  
        [DllImport("wininet.dll")]
        private extern static bool InternetGetConnectedState(out int Description, int ReservedValue);
        //Creating a function that uses the API function...  

        public static bool IsConnectedToInternet(out string message)
        {
            message = "";
            try
            {
                int Desc;
                return InternetGetConnectedState(out Desc, 0);
            }
            catch(Exception err)
            {
                message = err.ErrorMessageIncludingInnerExceptionMessage();
                return false;
            }
        }
    }


    /// <summary>
    /// Class <c>OnlineConnection</c> provides a set of methods to determine if an online connection is available
    /// </summary>
    public static class OnlineConnection
    {

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static bool CanConnectToANetwork()
        {
            bool canConnectOnLine = true;
            try
            {
                if (NetworkInterface.GetIsNetworkAvailable())
                {
                    canConnectOnLine = true;
                }
            }
            catch (Exception err)
            {
                canConnectOnLine = false;
                string s1 = err.Message;
            }
            return canConnectOnLine;
        }

        public static bool CanConnectOnLine()
        {
            string message = "";
            return CanConnectOnLine(out message);
        }



        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static bool CanConnectOnLine(out string ipStatusMessage)
        {
            bool canConnectOnLine = false;
            ipStatusMessage = "";
            string message;
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Computer name: " + ApplicationInformation.ComputerName);
            try
            {
                canConnectOnLine =  InternetCS.IsConnectedToInternet(out message);
                sb.AppendLine("Status: " + message.ToString());
                //Ping myPing = new Ping();
                //String host = "google.com";
                //byte[] buffer = new byte[32];
                //int timeout = 3000;
                //PingOptions pingOptions = new PingOptions();
                //PingReply reply = myPing.Send(host, timeout, buffer, pingOptions);
                //canConnectOnLine = (reply.Status == IPStatus.Success);
                //sb.AppendLine("Status: " + reply.Status.ToString());
            }
            catch (Exception err)
            {
                canConnectOnLine = false;
                sb.AppendLine(err.ErrorMessageIncludingInnerExceptionMessage());
            }
            if(canConnectOnLine == false)
                ipStatusMessage = sb.ToString();
            return canConnectOnLine;
        }
    }

    /// <summary>
    /// Class <c>OnLineConnections</c> provides a set of methods to determine if an online connection is available
    /// </summary>
    public static class OnlineConnections
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static bool CanConnectTo(string url)
        {
            try
            {
                using (var client = new WebClient())
                {
                    using (var stream = client.OpenRead(url))
                    {
                        return true;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string GetOnlineFileContents(string url)
        {
            string result = null;
            try
            {
                using (var client = new WebClient())
                {
                    using (var stream = client.OpenRead(url))
                    {
                        var content = client.DownloadData(url);
                        result = Encoding.UTF8.GetString(content);
                    }
                }
            }
            catch
            {
            }
            return result;
        }
    }
}
