﻿using System.Configuration;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Text;
using System.Threading;
using System;
using System.Drawing;


namespace mm.Utilities
{
    /// <summary>
    /// Class <c>OnStartUp</c> provides a set of methods suitable for running when starting a program 
    /// </summary>
    public class OnStartUp
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string GetFormTitle()
        {
            string versionNumber = ApplicationInformation.GetVersionNumber(3);
            if (versionNumber.EndsWith(".0"))
                versionNumber = ApplicationInformation.GetVersionNumber(2);
            return ApplicationInformation.ApplicationName + " (" + versionNumber + ")";
        }

        /// <summary>
        /// 
        /// </summary>
        public static void CloseApplicationIfAnotherVersionIsInExistance()
        {
            string applicationName = Path.GetFileNameWithoutExtension(Application.ExecutablePath);

            Mutex singleton = new Mutex(true, applicationName);
            if (!singleton.WaitOne(TimeSpan.Zero, true))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("A copy of " + applicationName + " is already running");
                sb.AppendLine("Only one copy may be run at any one time");
                sb.AppendLine("");
                sb.AppendLine("This second copy will now close");
                MessageBox.Show(sb.ToString(), "Information");
                Environment.Exit(0);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="askBeforeDeletingFile"></param>
        /// <returns></returns>
        public static bool RemoveACorruptConfigurationFile(bool askBeforeDeletingFile)
        {
            bool corruptConfigurationFileRemoved = false;
            try
            { 
                Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal);
            }
            catch (ConfigurationErrorsException ex)
            { //(requires System.Configuration)
                string filename = ex.Filename;
                string programName = Path.GetFileNameWithoutExtension(Process.GetCurrentProcess().ProcessName);
                if (askBeforeDeletingFile)
                {
                    if (MessageBox.Show(programName + " has detected that your" +
                                          " user settings file has become corrupted. " +
                                          "This may be due to a crash or improper exiting" +
                                          " of the program. " + programName + " must reset your " +
                                          "user settings in order to continue.\n\nClick" +
                                          " Yes to reset your user settings and continue.\n\n" +
                                          "Click No if you wish to attempt manual repair" +
                                          " or to rescue information before proceeding.",
                                          "Corrupt user settings",
                                          MessageBoxButtons.YesNo, MessageBoxIcon.None, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        File.Delete(filename);

                        //reload();
                        corruptConfigurationFileRemoved = true;
                        // you could optionally restart the app instead
                    }
                    else
                        Process.GetCurrentProcess().Kill();
                }

                // avoid the inevitable crash
                else
                {
                    MessageBox.Show(programName + " has detected that your" +
                                          " user settings file has become corrupted. " +
                                          "This may be due to a crash or improper exiting" +
                                          " of the program. \n\n" + programName + " will now reset your " +
                                          "user settings in order to continue", "Information");
                    File.Delete(filename);
                    //reload();
                    corruptConfigurationFileRemoved = true;
                }
            }
            return corruptConfigurationFileRemoved;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public static Point ValidateLocationOnScreen(SettingsBase settings, string propertyName)
        {
            Point location = convertStringToLocation((string)settings.Properties[propertyName].DefaultValue);
            try
            {
                Point locationToCheck = convertStringToLocation((string)settings.PropertyValues[propertyName].SerializedValue);
                foreach (Screen aScreen in Screen.AllScreens)
                {
                    if (aScreen.Bounds.Contains(locationToCheck))
                    {
                        location = locationToCheck;
                        break;
                    }
                }
            }
            catch { };
            return location;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="locationPropertyName"></param>
        /// <param name="sizePropertyName"></param>
        /// <returns></returns>
        public static Size ValidateSizeOnScreen(SettingsBase settings, string locationPropertyName, string sizePropertyName)
        {
            Point location = ValidateLocationOnScreen(settings, locationPropertyName);
            Size size = convertStringToSize((string)settings.Properties[sizePropertyName].DefaultValue);
            try
            {
                Size sizeToCheck = convertStringToSize(settings.PropertyValues[sizePropertyName].SerializedValue);
                foreach (Screen aScreen in Screen.AllScreens)
                {
                    if (aScreen.Bounds.Contains(location))
                    {
                        if ((sizeToCheck.Width < aScreen.Bounds.Size.Width) &&
                            (sizeToCheck.Height < aScreen.Bounds.Size.Height))
                        {
                            Point bottomRHCorner = new Point(location.X + sizeToCheck.Width, location.Y + sizeToCheck.Height);
                            if (aScreen.Bounds.Contains(bottomRHCorner))
                                size = sizeToCheck;
                        }
                        break;
                    }
                }
            }
            catch { };
            return size;
        }

        private static Point convertStringToLocation(object locationAsObject)
        {
            int x = 100;
            int y = 100;
            try
            {
                string locationAsString = (string)locationAsObject;
                x = Convert.ToInt16(locationAsString.Substring(0, locationAsString.IndexOf(",")));
                y = Convert.ToInt16(locationAsString.Substring(locationAsString.IndexOf(",") + 1));
            }
            catch { };
            return new Point(x, y);
        }

        private static Size convertStringToSize(object sizeAsObject)
        {
            int width = 400;
            int height = 400;
            try
            {
                string sizeAsString = (string)sizeAsObject;
                width = Convert.ToInt16(sizeAsString.Substring(0, sizeAsString.IndexOf(",")));
                height = Convert.ToInt16(sizeAsString.Substring(sizeAsString.IndexOf(",") + 1));
            }
            catch { };
            return new Size(width, height);
        }
    }
}

