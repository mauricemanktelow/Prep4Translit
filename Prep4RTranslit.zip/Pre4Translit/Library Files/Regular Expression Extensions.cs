﻿using System.Text.RegularExpressions;

namespace mm.Extensions
{
    /// <summary>
    /// 
    /// </summary>
    public static class RegularExpressionExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="regEx"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public static bool IsValidPattern(this Regex regEx, string pattern)
        {
            bool isvalidExpression = false;
            if (string.IsNullOrEmpty(pattern) == false)
            {
                try
                {
                    isvalidExpression = Regex.IsMatch("Some text to validate", pattern);
                    isvalidExpression = true;
                }
                catch { }
            }
            return isvalidExpression;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aMatch"></param>
        /// <returns></returns>
        public static bool HasContent(this Match aMatch)
        {
            return string.IsNullOrWhiteSpace(aMatch.Value) == false;
        }
    }

}
