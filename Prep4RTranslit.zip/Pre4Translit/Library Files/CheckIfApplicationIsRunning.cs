﻿using System;
using System.Diagnostics;

namespace mm.Utilities
{
   public class CheckIfApplicationIsRunning
    {
        public static bool CheckForApplicationNow(string applicationName)
        {
            bool applicationIsRunning = false;

            Process[] procs = Process.GetProcesses();
       
            foreach (Process proc in procs)
            {
                try
                {
                    if (proc.MainWindowHandle != new IntPtr(0) && !proc.HasExited)
                    {
                        ProcessModule[] arr = new ProcessModule[proc.Modules.Count];

                        foreach (ProcessModule pm in proc.Modules)
                        {
                            if (String.Equals(pm.ModuleName, applicationName, StringComparison.OrdinalIgnoreCase))
                            {
                                applicationIsRunning = true;
                                break;
                            }
                        }
                    }
                }
                catch (Exception) { }
            }
            return applicationIsRunning;
        }
    }
}
