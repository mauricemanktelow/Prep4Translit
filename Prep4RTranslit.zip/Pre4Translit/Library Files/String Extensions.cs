﻿using System;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Collections.Generic;
using System.Xml.Serialization;
using mm.ConstantsSpecifications;
using mm.Utilities;

namespace mm.Extensions
{
    /// <summary>
    /// 
    /// </summary>
    public struct StringUnicodeValues
    {
        public readonly char Character;
        public readonly string UnicodeValue;

        public StringUnicodeValues(char character, string unicodeValue)
        {
            Character = character;
            UnicodeValue = "u+" + unicodeValue;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public static class StringExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static bool StartsWithASpace(this string inputStr)
        {
            return (inputStr != null) && (inputStr.Length > 0) && (inputStr[0] == ' ');
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static bool EndsWithASpace(this string inputStr)
        {
            return (inputStr != null) && (inputStr.Length > 0) && (inputStr[inputStr.Length - 1] == ' ');
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static bool IsSpaces(this string inputStr)
        {
            bool isSpaces = false;
            if ((inputStr != null) && (inputStr.Length > 0))
            {
                isSpaces = true;
                foreach (char aChar in inputStr)
                {
                    if (aChar != ' ')
                    {
                        isSpaces = false;
                        break;
                    }
                }
            }
            return isSpaces;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static string RemoveMultipleSpaces(this string inputStr)
        {
            while (inputStr.Contains("  "))
                inputStr = inputStr.Replace("  ", " ");
            return inputStr;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static string TrimDirectionMarkers(this string inputStr)
        {
            return Unicode.RemoveAnyDirectionalMarker(inputStr);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="xmlString"></param>
        /// <returns></returns>
        public static T DeserializeXmlString<T>(this string xmlString)
        {
            var serializer = new XmlSerializer(typeof(T));
            using (TextReader reader = new StringReader(xmlString))
            {
                return (T)serializer.Deserialize(reader);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static object Deserialize(this string input, object obj)
        {
            XmlSerializer ser = null;
            try
            {
                ser = new System.Xml.Serialization.XmlSerializer(obj.GetType());

                using (StringReader sr = new StringReader(input))
                    return ser.Deserialize(sr);
            }
            catch (Exception err)
            {
                MessageBox.Show("Error deserialise xml string: " + err.Message, "Information");
            }
            return ser;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputString"></param>
        /// <returns></returns>
        public static string ReplaceDirectionalMarkers(this string inputString)
        {
            return inputString.Replace(Unicode.Ltr_embed.ToString(), "→").Replace(Unicode.Pop_Directional.ToString(), "←").Replace(Unicode.LeftToRightMark.ToString(), "⇉").Replace(Unicode.RightToLeftMark.ToString(), "⇇");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static char ReplaceDirectionalMarkers(this char aChar)
        {
            char thisChar = aChar;
            switch (aChar)
            {
                case Unicode.Ltr_embed:
                    thisChar = '→';
                    break;
                case Unicode.Pop_Directional:
                    thisChar = '←';
                    break;
                case Unicode.LeftToRightMark:
                    thisChar = '⇉';
                    break;
                case Unicode.RightToLeftMark:
                    thisChar = '⇇';
                    break;
            }
            return thisChar;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="thisString"></param>
        /// <returns></returns>
        public static List<StringUnicodeValues> GetUnicodeValues(this String thisString)
        {
            List<StringUnicodeValues> unicodeValues = new List<StringUnicodeValues>();
            foreach (Char aChar in thisString)
            {
                string hexValue = "";
                char thisChar = ReplaceDirectionalMarkers(aChar);
                hexValue = ((int)thisChar).ToString("X4");
                unicodeValues.Add(new StringUnicodeValues(thisChar, hexValue));
            }
            return unicodeValues;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="thisString"></param>
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        /// <param name="stringComparison"></param>
        /// <returns></returns>
        public static string Replace(this String thisString, string oldValue, string newValue, StringComparison stringComparison)
        {
            string working = thisString;
            int index = working.IndexOf(oldValue, stringComparison);
            while (index != -1)
            {
                working = working.Remove(index, oldValue.Length);
                working = working.Insert(index, newValue);
                index = index + newValue.Length;
                index = working.IndexOf(oldValue, index, stringComparison);
            }
            return working;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="hex"></param>
        /// <returns></returns>
        public static string ConvertHexValueToCharacterAsString(this string hex)
        {
            string result = hex;
            if ((hex.Length == 6) && ((hex.Substring(0, 2) == "u+") || (hex.Substring(0, 2) == @"\x")))
            {
                hex = hex.Substring(2); // To remove leading u+
                int num = int.Parse(hex, NumberStyles.AllowHexSpecifier);
                char aChar = (char)num;
                result = aChar.ToString();
            }
            else
                Beep.SingleBeep();
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="text"></param>
        /// <param name="location"></param>
        /// <returns></returns>
        public static string GetWordAtLocation(this string text, int location)
        {
            int start = location;
            while ((start > -0) && (Char.IsLetter(text[start - 1])))
            {
                start--;
            }
            int end = location;
            while ((end < text.Length - 1) && (Char.IsLetter(text[end + 1])))
            {
                end++;
            }
            return text.Substring(start, end - start + 1);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string TrimNumbersAtEnd(this string text)
        {
            while ((text.Length > 0) && Char.IsNumber(text[text.Length - 1]))
                text = text.Substring(0, text.Length - 1);
            return text;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="text"></param>
        /// <param name="maxLength"></param>
        /// <returns></returns>
        public static string WrapText(string text, int maxLength)
        {
            int index = maxLength;
            //while (index < text.Length - 1)
            {
                while ((index < text.Length - 1) && (text[index] != ' '))
                {
                    index++;
                }
            }
            if (index < text.Length - 1)
                text = text.Substring(0, index) + "\n" +
                               WrapText(text.Substring(index + 1), maxLength);
            return text;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="text"></param>
        /// <param name="location"></param>
        /// <returns></returns>
        public static string GetWordStartingAtLocation(this string text, int location)
        {
            string word = "";
            if ((location > -1) && (location < text.Length))
            {
                word = text.Substring(location, text.IndexOf(' ', location) - location);
            }
            return word;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="text"></param>
        /// <param name="currentPosition"></param>
        /// <returns></returns>
        public static int LineStartsAt(this string text, int currentPosition)
        {
            int lineStartsAt = -1;
            if (currentPosition > -1)
            {
                Char[] newLineCharacters = { '\n', '\r' };
                lineStartsAt = text.LastIndexOfAny(newLineCharacters, currentPosition);
            }
            return lineStartsAt;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="previousText"></param>
        /// <returns></returns>
        public static bool PreviousTextIsCompoundWord(ref string previousText)
        {
            return Regex.IsMatch(previousText, @"\p{P}*[" + Constants.AmbiguousHyphenUnicodeValue + @"\p{L}]+\p{P}*");
        }

        public static bool IsASpeechMark(this string inputStr)
        {
            bool result = false;
            result = ((inputStr.Length == 1) && (Char.IsPunctuation(inputStr[0])));
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static string Normalise(this string inputStr)
        {
            inputStr = Regex.Replace(inputStr, "([ ]{2,})", " ");
            inputStr = Regex.Replace(inputStr, "[ ]+([\n\r])", "$1"); // Remove line trailing spaces
            inputStr = Regex.Replace(inputStr, "([\n\r])[ ]+", "$1"); // Remove line leading spaces
            inputStr = Regex.Replace(inputStr, @"([“’«›])([‘”»‹])", "$1 $2");
            return inputStr;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="previousText"></param>
        /// <returns></returns>
        public static bool PreviousTextIsASFM(string previousText)
        {
            return (previousText.Length > 0) && (previousText[0] == '\\');
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="index"></param>
        /// <param name="noOfCharacters"></param>
        /// <returns></returns>
        public static string PrevString(this string inputStr, int index, int noOfCharacters)
        {
            int length = noOfCharacters;
            int startsAt = index - noOfCharacters;
            if (startsAt < 0)
            {
                length = index;
                startsAt = 0;
            }
            return inputStr.Substring(startsAt, length);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static bool EndsWithASpaceOrNewLine(this string inputStr)
        {
            bool result = false;
            if (inputStr.Length > 0)
            {
                Char lastChar = inputStr[inputStr.Length - 1];
                result = (lastChar == ' ') || (lastChar == '\n') || (lastChar == '\r');
            }
            return result;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="hex"></param>
        /// <returns></returns>
        public static string GetCharFomHex(this string hex)
        {
            string result = "";
            try
            {
                int value = Convert.ToInt32(hex, 16);
                char charValue = (char)value;
                result = charValue.ToString();
            }
            catch (Exception err)
            {
                string str = err.Message;
                MessageBox.Show("Cannot convert " + hex + " as a hex value to string", "Error");
            }
            return result;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static bool ContainsAHyphen(this String inputStr)
        {
            bool result = false;
            if ((inputStr.Length > 0) && (!LastCharIs(inputStr, ' ')))
            {
                result = Regex.IsMatch(inputStr, "[" + Constants.AllHyphensAndDashes + "]");
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static bool ContainsADiacritic(this string inputStr)
        {
            bool result = false;
            if ((inputStr.Length > 0) && (!LastCharIs(inputStr, ' ')))
            {
                for (int index = 0; index < inputStr.Length; index++)
                {
                    Char aChar = inputStr[index];
                    if (aChar.IsCharacterADiacritic())
                    {
                        result = true;
                        break;
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static bool IsTextANumber(this String inputStr)
        {
            bool result = false;
            if (String.IsNullOrEmpty(inputStr.Trim()) == false)
            {
                int myInt;
                result = int.TryParse(inputStr, out myInt);
            }
            return result;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static bool OnlyContainsPunctuation(this string inputStr)
        {
            bool result = true;
            char[] allCharactersInWord = inputStr.ToCharArray();
            foreach (Char aChar in allCharactersInWord)
            {
                if ((Char.IsPunctuation(aChar) == false)
                    || (aChar == '@'))
                {
                    result = false;
                    break;
                }
            }
            return result;

        }

        /// <summary>
        /// Check if index value is valid
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="i"></param>
        /// <returns></returns>
        public static bool IsValidIndex(this string inputStr, int i)
        {
            return (i >= 0) && (i < inputStr.Length);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static bool IsNumber(this String inputStr)
        {
            bool isNumber = false;
            if (inputStr.Length > 0)
            {
                isNumber = true;
                foreach (Char aChar in inputStr)
                {
                    if (!Char.IsDigit(aChar))
                    {
                        isNumber = false;
                        break;
                    }
                }
            }
            return isNumber;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static bool IsNumberAsText(this string inputStr)
        {
            bool isNumber = false;
            switch (inputStr.ToLower())
            {
                case "zero":
                case "naught":
                case "nought":
                case "one":
                case "two":
                case "three":
                case "four":
                case "five":
                case "six":
                case "seven":
                case "eight":
                case "nine":
                case "ten":
                case "eleven":
                case "twelve":
                case "thirteen":
                case "fourteen":
                case "fifteen":
                case "sixteen":
                case "seventeen":
                case "eighteen":
                case "nineteen":
                case "twenty":
                case "thirty":
                case "fourty":
                case "fifty":
                case "sixty":
                case "seventy":
                case "eighty":
                case "ninety":
                case "hundred":
                case "thousand":
                case "million":
                    isNumber = true;
                    break;
            }
            return isNumber;
        }

        /// <summary>
        /// Checks if there is any non-space content in the string i.e. not null, empty or white space
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static bool HasContents(this string inputStr)
        {
            return !String.IsNullOrEmpty(inputStr.Trim());
        }

        /// <summary>
        /// Checks if there is any content (inclduing spaces) in the string
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static bool IsNotEmpty(this string inputStr)
        {
            return !String.IsNullOrEmpty(inputStr);
        }

        /// <summary>
        /// Get first character in string
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static Char FirstChar(this string str)
        {
            Char firstChar = '\0';
            if (str.Length > 0)
            {
                firstChar = str[0];
            }
            return firstChar;
        }

        /// <summary>
        /// Get last character in string
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static Char LastChar(this string inputStr)
        {
            Char lastChar = '\0';
            if (IsNotEmpty(inputStr))
            {
                lastChar = inputStr[inputStr.Length - 1];
            }
            return lastChar;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static bool LastCharIs(this string inputStr, Char aChar)
        {
            bool result = false;
            if (!String.IsNullOrEmpty(inputStr))
                result = LastChar(inputStr) == aChar;
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static string TrimPunctuation(this string inputStr)
        {
            while (inputStr.Length > 0 && Char.IsPunctuation(inputStr[0]))
                inputStr = inputStr.Substring(1);
            while (inputStr.Length > 0 && Char.IsPunctuation(LastChar(inputStr)))
                inputStr = inputStr.Substring(0, inputStr.Length - 1);
            return inputStr;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        public static string TrimToSFM(this string inputStr)
        {
            int indexOfSlash = inputStr.IndexOf('\\');
            if (indexOfSlash > 0)
                inputStr = inputStr.Substring(0, indexOfSlash);
            return inputStr;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static string TrimPunctuationLeft(this string inputStr)
        {
            while (inputStr.Length > 0 && Char.IsPunctuation(inputStr[0]))
                inputStr = inputStr.Substring(1);
            return inputStr;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public static string GetPrevWord(this string inputStr, int index)
        {
            int startsAt = index;
            while ((startsAt > 0) && (Char.IsSeparator(inputStr[startsAt - 1]) == false))
            {
                startsAt--;
            }
            return inputStr.Substring(startsAt, index - startsAt);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static string TrimPunctuationRight(this string inputStr)
        {
            while (inputStr.Length > 0 && Char.IsPunctuation(LastChar(inputStr)))
                inputStr = inputStr.Substring(0, inputStr.Length - 1);
            return inputStr;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="comparison"></param>
        /// <returns></returns>
        public static bool EndsWith(this string inputStr, string comparison)
        {
            return EndsWith(inputStr, comparison, true);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="comparison"></param>
        /// <param name="caseSensitive"></param>
        /// <returns></returns>
        public static bool EndsWith(this string inputStr, string comparison, bool caseSensitive)
        {
            bool result = false;
            if ((inputStr != null) && (comparison != null))
            {
                if (caseSensitive == false)
                {
                    inputStr = inputStr.ToLower();
                    comparison = comparison.ToLower();
                }
                if (inputStr.Length >= comparison.Length)
                    result = inputStr.Substring(inputStr.Length - comparison.Length) == comparison;
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="previousText"></param>
        /// <returns></returns>
        public static bool PrevNoneSpaceCharacterIsNotAHyphen(this string previousText)
        {
            bool result = true;
            previousText = previousText.TrimEnd();
            if (IsNotEmpty(previousText))
            {
                Char prevChar = previousText[previousText.Length - 1];
                result = !prevChar.IsCharacterAHyphen();
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public static int IndexOfNextSeperator(this string inputStr, int index)
        {
            int result = -1;
            if (index < 0)
                index = 0;
            int indexOfSpace = inputStr.IndexOf(' ', index);
            int indexOfLineFeed = inputStr.IndexOf('\n', index);
            int indexOfCarraigeReturn = inputStr.IndexOf('\r', index);
            int indexOfTab = inputStr.IndexOf('\t', index);
            if (indexOfSpace > 0)
                result = indexOfSpace;
            if (indexOfLineFeed > 0)
            {
                if (result == -1)
                    result = indexOfLineFeed;
                else
                    result = Math.Min(result, indexOfLineFeed);
            }
            if (indexOfCarraigeReturn > 0)
            {
                if (result == -1)
                    result = indexOfCarraigeReturn;
                else
                    result = Math.Min(result, indexOfCarraigeReturn);
            }
            if (indexOfTab > 0)
            {
                if (result == -1)
                    result = indexOfTab;
                else
                    result = Math.Min(result, indexOfTab);
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public static Char FollowingChar(this string inputStr, int index)
        {
            return FollowingChar(inputStr, index, 1);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="index"></param>
        /// <param name="offSet"></param>
        /// <returns></returns>
        public static Char FollowingChar(this string inputStr, int index, int offSet)
        {
            Char result = '\0';
            //if (index < text.Length + offSet)
            //    result = text[index + offSet];
            if ((index + offSet) < inputStr.Length)
                result = inputStr[index + offSet];
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public static Char PrevChar(this string inputStr, int index)
        {
            return PrevChar(inputStr, index, 1);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="index"></param>
        /// <param name="offSet"></param>
        /// <returns></returns>
        public static Char PrevChar(this string inputStr, int index, int offSet)
        {
            Char result = '\0';
            if ((index + offSet > 0) &&
                (index + offSet < inputStr.Length))
                result = inputStr[index - offSet];
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="startsAt"></param>
        /// <returns></returns>
        public static string GetNextWord(this String inputStr, int startsAt)
        {
            string result = "";
            if (startsAt < inputStr.Length)
            {
                if (startsAt < 0)
                    startsAt = 0;
                int endsAt = IndexOfNextSeperator(inputStr, startsAt);
                if (endsAt > 0)
                    result = inputStr.Substring(startsAt, endsAt - startsAt);
                else
                    result = inputStr.Substring(startsAt);
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="chartToCount"></param>
        /// <returns></returns>
        public static int CharacterFrequency(this string inputStr, Char chartToCount)
        {
            int count = 0;
            int length = inputStr.Length;
            for (int index = length - 1; index >= 0; index--)
            {
                if (inputStr[index] == chartToCount)
                    count++;
            }
            return count;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static int NoOfHyphensInWord(this string inputStr)
        {
            int result = 0;
            foreach (Char aChar in inputStr)
            {
                if (aChar.IsCharacterAHyphen())
                    result = result + 1;
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static bool AppendToFile(this string inputStr, string fileName, bool appendToStart, out string errorMessage)
        {
            bool textAppended = true;
            errorMessage = "";
            try
            {
                if (appendToStart)
                    SaveAs(inputStr, fileName);
                else
                    AppendToFile(inputStr, fileName, out errorMessage);
            }
            catch (Exception err)
            {
                errorMessage = err.Message;
                textAppended = false;
            }
            return textAppended;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static bool AppendToFile(this string inputStr, string fileName, out string errorMessage)
        {
            bool textAppended = true;
            errorMessage = "";
            try
            {
                File.AppendAllText(fileName, inputStr);
            }
            catch (Exception err)
            {
                errorMessage = err.Message;
                textAppended = false;
            }
            return textAppended;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="fileName"></param>
        /// <param name="encoding"></param>
        /// <param name="normalise"></param>
        /// <returns></returns>
        public static bool SaveAsWithEncoding(this string inputStr, string fileName, Encoding encoding, bool normalise)
        {
            bool fileSaved = false;
            if (encoding == null)
                encoding = Encoding.UTF8;
            try
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(Path.GetDirectoryName(fileName));
                FileInfo fileInfo = new FileInfo(fileName);
                if (DirectoryExtensions.CanCreateFileInDirectory(directoryInfo))
                {
                    using (StreamWriter writer = new StreamWriter(fileName, false, encoding))
                    {
                        if (normalise)
                            writer.Write(inputStr.Normalise());
                        else
                            writer.Write(inputStr);
                        fileSaved = true;
                    }
                }
                else
                {
                    MessageBox.Show("Cannot save file. Is directory read only?", "Information");
                }
            }
            catch (Exception err)
            {
                string str = err.Message;
                MessageBox.Show("Unable to save document", "Information");
            }
            return fileSaved;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static bool SaveAs(this string inputStr, string fileName)
        {
            return SaveAsWithEncoding(inputStr, fileName, Encoding.UTF8, false);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="fileName"></param>
        /// <param name="normalise"></param>
        /// <returns></returns>
        public static bool SaveAs(this string inputStr, string fileName, bool normalise)
        {
            return SaveAsWithEncoding(inputStr.Normalise(), fileName, Encoding.UTF8, normalise);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="fileName"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        public static bool SaveAs(this string inputStr, string fileName, Encoding encoding)
        {
            return SaveAsWithEncoding(inputStr.Normalise(), fileName, encoding, false);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="zipFileContainerName"></param>
        /// <returns></returns>
        public static string LoadFromFile(string fileName, string zipFileContainerName, string errorMessage)
        {
            return LoadFromZipFile(fileName, zipFileContainerName, false, errorMessage);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="zipFileContainerName"></param>
        /// <param name="normalise"></param>
        /// <returns></returns>
        public static string LoadFromZipFile(string fileName, string zipFileContainerName, bool normalise, string errorMessage)
        {
            string result = "";
            try
            {
                if ((bool)ParameterFileProcessing.CheckDatxFileExists(zipFileContainerName))
                {
                    if ((bool)ParameterFileProcessing.CheckContentFileExists(fileName, zipFileContainerName))
                    {
                        result = ParameterFileProcessing.GetString(zipFileContainerName, fileName);
                        if (normalise)
                            result = result.Normalise();
                    }
                    else
                        MessageBox.Show("File " + fileName + " does not exist in zip file " + zipFileContainerName, "Information");
                }
                else
                    MessageBox.Show("File " + zipFileContainerName + " does not exist", "Information");
            }
            catch (Exception err)
            {
                MessageBox.Show("Error " + err.Message + " found when trying to read file " + fileName + " in zip file " + zipFileContainerName, "Information");
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="normalize"></param>
        /// <returns></returns>
        public static string LoadFromFile(string fileName, bool normalize)
        {
            string result = "";
            FileStream fileStream = null;
            try
            {
                fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using (StreamReader reader = new StreamReader(fileStream, Encoding.Default))
                {
                    fileStream = null;
                    result = reader.ReadToEnd();
                    if (normalize)
                        result = result.Normalise();
                }
            }
            catch (Exception err)
            {
                string str = err.Message;
                MessageBox.Show("Unable to load file", "Informatiuon");
            }
            finally
            {
                if (fileStream != null)
                    fileStream.Dispose();
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static string LoadFromFile(string fileName)
        {
            return LoadFromFile(fileName, false);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="chartToCount"></param>
        /// <returns></returns>
        public static int ChararcterFrequency(this string inputStr, Char chartToCount)
        {
            int count = 0;
            int length = inputStr.Length;
            for (int index = length - 1; index >= 0; index--)
            {
                if (inputStr[index] == chartToCount)
                    count++;
            }
            return count;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inoutStr"></param>
        /// <returns></returns>
        public static int NumberOfSpacesAtStart(this string inoutStr)
        {
            int count = 0;
            while ((inoutStr.Length > 0) && (inoutStr[0] == ' '))
            {
                count++;
                inoutStr = inoutStr.Substring(1);
            }
            return count;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static int NumberOfSpacesAtEnd(this string inputStr)
        {
            int count = 0;
            while ((inputStr.Length > 0) && (inputStr[inputStr.Length - 1] == ' '))
            {
                count++;
                inputStr = inputStr.Substring(0, inputStr.Length - 1);
            }
            return count;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static bool IsAsciiText(this string inputStr)
        {
            bool stringIsAscii = true;
            foreach (char aChar in inputStr)
            {
                if (aChar.IsCharacterInAsciiRange() == false)
                {
                    stringIsAscii = false;
                }
            }
            return stringIsAscii;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <param name="startSearchAt"></param>
        /// <returns></returns>
        public static int IndexOfEndOfLine(this string inputStr, int startSearchAt)
        {
            int indexOfEndOfLine = inputStr.Length;
            if (startSearchAt > 0)
                inputStr = inputStr.Substring(startSearchAt);
            int indexOfNewLine = inputStr.IndexOf("\n");
            int indexOfCarraigeReturn = inputStr.IndexOf("\r");
            if (indexOfNewLine > 0)
            {
                if (indexOfCarraigeReturn > 0)
                    indexOfEndOfLine = Math.Min(indexOfNewLine, indexOfCarraigeReturn);
                else
                    if (indexOfNewLine > -1)
                    indexOfEndOfLine = indexOfNewLine;
            }
            else
                if (indexOfCarraigeReturn > -1)
                indexOfEndOfLine = indexOfCarraigeReturn;
            return indexOfEndOfLine;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static string removeAllSpacesAtStartAndEndOfLines(this string inputStr)
        {
            string pattern = @"[ ]+[\n\r]+";
            if (inputStr.Contains(" \n"))
                inputStr = Regex.Replace(inputStr, pattern, "\n");
            pattern = @"[\n\r]+[ ]+";
            if (inputStr.Contains("\n "))
                inputStr = Regex.Replace(inputStr, pattern, "\n");
            return inputStr;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static Stream ToStream(this string str)
        {
            MemoryStream stream = new MemoryStream();
            StreamWriter writer = new StreamWriter(stream);
            writer.Write(str);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="textToSave"></param>
        /// <param name="fileName"></param>
        public static void SaveToTemporaryFile(this string textToSave, out string fileName)
        {
            fileName = Path.GetTempFileName();
            FileInfo fileInfo = new FileInfo(fileName);
            fileInfo.Attributes = FileAttributes.Temporary;
            File.WriteAllText(fileName, textToSave);
        }
    }
}


