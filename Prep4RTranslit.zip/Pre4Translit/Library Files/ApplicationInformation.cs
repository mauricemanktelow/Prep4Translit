﻿using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System;

namespace mm.Utilities
{
    /// <summary>
    /// Class <c>ApplicationVersionNumber</c>contains methods to extract / process the applicaiton version number  
    /// </summary>
    public class ApplicationInformation
    {

        public static string ApplicationName
        { get { return Application.ProductName; } }

        public static string GetApplicationDirectory
        { get { return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location); } }

        public static string ComputerName { get { return Environment.MachineName; } }


        /// <summary>
        /// Method <c>GetNow</c> returns the version number as a string
        /// </summary>
        /// <param name="accuracy">Determins the number of decimal places shown in the version number</param>
        /// <returns></returns>
        public static string GetVersionNumber(int accuracy)
        {
            string assemblyVersion = Assembly.GetExecutingAssembly().GetName().Version.ToString();
            for(int count = 0; count < 4-accuracy; count++)
                assemblyVersion = assemblyVersion.Substring(0, assemblyVersion.LastIndexOf('.'));
            return assemblyVersion;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="extension"></param>
        /// <returns></returns>
        public static string GetDebugFilenameAndPath(string extension)
        {
            string applicationFileName = AppDomain.CurrentDomain.FriendlyName;
            string debugDirectory = AppDomain.CurrentDomain.BaseDirectory + @"\Debug\";
            string debugFileName = Path.GetFileNameWithoutExtension(applicationFileName) + @"." + extension;
            return debugDirectory + debugFileName;
        }

    }
}
