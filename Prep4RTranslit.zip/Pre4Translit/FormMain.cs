﻿using System;
using System.Windows.Forms;
using TransliterateNameSpace;
using mm.BackgroundWorkerNameSpace;

namespace Prep4Translit
{

    /* This software is issued as OpenSource under an MIT Licence - see https://opensource.org/licenses/MIT
     * 
     * 
     * Background discussion paper on mixed directional text 
     * 
     * https://docs.microsoft.com/en-us/dynamics365/fin-ops-core/dev-itpro/user-interface/bidirectional-support
     */

    public partial class FormMain : Form
    {
        Transliterate transliterate = new Transliterate();
        BackgroundWorkerParameters workerParams;


        public FormMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            OnLoading();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = OnClosing() == false;
        }


        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showAboutInformation();
        }

        private void checkBoxHideWelcomeMessage_CheckedChanged(object sender, EventArgs e)
        {
            hideMessageWhneOpeningApplicationNextTime();
        }

        private void buttonRunNow_Click(object sender, EventArgs e)
        {
            runNow();
        }

        private void backgroundWorker_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            Transliterate.ProcessDocumentNow(workerParams);
        }

        private void backgroundWorker_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            if ((e.ProgressPercentage % 10) == 0)
                toolStripProgressBar.Value = e.ProgressPercentage;
        }

        private void backgroundWorker_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            runCompleted(workerParams);
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resetAllValuesToDefaultValues();
        }

        private void comboBoxLanguageBlock_TextChanged(object sender, EventArgs e)
        {
            if (comboBoxLanguageBlock.Text == "Other")
                labelExample.Text = "e.g. U+0400-U+04FF for Cyrillic";
            else
                labelExample.Text = "";
        }
    }
}
