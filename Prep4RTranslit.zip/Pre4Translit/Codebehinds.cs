﻿using System.Windows.Forms;
using System.Drawing;
using System;
using System.Collections.Specialized;
using System.IO;
using mm.BackgroundWorkerNameSpace;
using TransliterateNameSpace;
using System.Text;
using System.Text.RegularExpressions;
using mm.Extensions;
using mm.Utilities;


namespace Prep4Translit
{
    public partial class FormMain : Form
    {

        bool programShouldBeRunAsASingleton = true;
        Transliterate.PatternValidity patternValidity = Transliterate.PatternValidity.NotKnown;

        private void OnLoading()
        {
            labelExample.Text = "";
            Text = OnStartUp.GetFormTitle();
            if (programShouldBeRunAsASingleton)
                OnStartUp.CloseApplicationIfAnotherVersionIsInExistance();

            if (OnStartUp.RemoveACorruptConfigurationFile(false))
            {
                Properties.Settings.Default.Reload();
                Properties.Settings.Default.UpgradeRequired = false;
                Properties.Settings.Default.Save();
            }
            else
            if (Properties.Settings.Default.UpgradeRequired)
            {
                Properties.Settings.Default.Upgrade();
                Properties.Settings.Default.UpgradeRequired = false;
                Properties.Settings.Default.Save();
            }

            Location = OnStartUp.ValidateLocationOnScreen(Properties.Settings.Default, "Location");
            Size = OnStartUp.ValidateSizeOnScreen(Properties.Settings.Default, "Location", "Size");

            textBoxTransliteratedStyle.Text = Properties.Settings.Default.StyleToApplyToTransliteratedText;

            toolStripStatusLabelFileName.Text = "";
            toolStripProgressBar.Value = 0;
            textBoxTransliteratedStyle.Text = Properties.Settings.Default.StyleToApplyToTransliteratedText;

            comboBoxLanguageBlock.Text = Properties.Settings.Default.SearchPattern;
            textBoxOpeningDelimiter.Text = Properties.Settings.Default.OpeningDelimiter;
            textBoxClosingDelimiter.Text = Properties.Settings.Default.ClosingDelimiter;

            labelNumberOfInsertions.Visible = false;

            WelcomeMessageInitialise();

        }


        private bool OnClosing()
        {
            bool canClose = true;
            if (canClose)
            {
                switch (WindowState)
                {
                    case FormWindowState.Normal:
                        Properties.Settings.Default.Size = Size;
                        Properties.Settings.Default.Location = Location;
                        break;
                    case FormWindowState.Maximized:
                        break;
                    case FormWindowState.Minimized:
                        break;
                }
            }
            if (String.IsNullOrWhiteSpace(textBoxTransliteratedStyle.Text) == false)
                Properties.Settings.Default.StyleToApplyToTransliteratedText = textBoxTransliteratedStyle.Text;
            if (string.IsNullOrWhiteSpace(comboBoxLanguageBlock.Text) == false)
                Properties.Settings.Default.SearchPattern = comboBoxLanguageBlock.Text;
            Properties.Settings.Default.OpeningDelimiter = textBoxOpeningDelimiter.Text;
            Properties.Settings.Default.ClosingDelimiter = textBoxClosingDelimiter.Text;
            Properties.Settings.Default.Save();
            return canClose;
        }

        private void showAboutInformation()
        {
            using (AboutBox aboutBox = new AboutBox())
            {
                aboutBox.logoPictureBox.Image = Icon.ToBitmap();
                aboutBox.Accuracylevel = 2;
                aboutBox.ShowDialog();
            }
        }

        private void runNow()
        {
            string styleToApply = "";
            if (validateInput())
            {
                string initialFileName = getInitialFileName();
                if (initialFileName == "")
                    MessageBox.Show("File conversion cancelled", "Information");
                else
                if (Path.GetExtension(initialFileName) != ".docx")
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("You are attempting to open a files which is not a Word document (i.e. a file ending in docx)");
                    sb.AppendLine("");
                    sb.AppendLine("File conversion cancelled - please try again");
                    MessageBox.Show(sb.ToString(), "Information");
                }
                else
                {
                    switch(MicrosoftWordProcessing.CheckStyleExists(initialFileName, textBoxTransliteratedStyle.Text.Trim(), out styleToApply))
                    {
                        case MicrosoftWordProcessing.CheckResults.Notknown:
                        case MicrosoftWordProcessing.CheckResults.EmptyString:
                            break;
                        case MicrosoftWordProcessing.CheckResults.StyleDoesNotExist:
                            StringBuilder sb = new StringBuilder();
                            sb.AppendLine("Style " + textBoxTransliteratedStyle.Text + " to be added to transilerated text does not exist in the original word document");
                            sb.AppendLine("");
                            sb.AppendLine("Please ensure that this style exists in original before conversion can proceed");
                            MessageBox.Show(sb.ToString(), "Information");
                            break;
                        case MicrosoftWordProcessing.CheckResults.StyleExists:
                            string updatedFileName = getUpdatedFileName(initialFileName);
                            if (updatedFileName == "")
                                MessageBox.Show("File conversion cancelled", "Information");
                            else
                            {
                                Cursor = Cursors.WaitCursor;
                                FileInfo fileInfo = new FileInfo(initialFileName);
                                toolStripStatusLabelFileName.Text = fileInfo.ShrinkPath(60, "...");
                                workerParams = new BackgroundWorkerParameters(Transliterate.DefaultSearchPattern(comboBoxLanguageBlock.Text, out patternValidity),
                                                                                styleToApply,
                                                                                textBoxOpeningDelimiter.Text,
                                                                                textBoxClosingDelimiter.Text,
                                                                                toolStripProgressBar,
                                                                                initialFileName,
                                                                                updatedFileName,
                                                                                @"word/document.xml",
                                                                                backgroundWorker);
                                backgroundWorker.RunWorkerAsync();
                            }
                            break;
                    }
                }
            }
        }

        private void runCompleted(BackgroundWorkerParameters workerParams)
        {
            if(workerParams.TransliterationCompletedSuccessfully)
            {
                labelNumberOfInsertions.Text = "Number of transliteration insertions: " + workerParams.NumberOfTransliterationsCreated.ToString();
                labelNumberOfInsertions.Visible = true;
                toolStripProgressBar.Value = 100;
                MessageBox.Show("Completed", "Information");
                toolStripProgressBar.Value = 0;
            }
            else
            {
                labelNumberOfInsertions.Visible = false;
                toolStripProgressBar.Value = 0;
                MessageBox.Show("Unable to complete transliteration", "Information");
            }
            Cursor = Cursors.Default;
        }

        private bool validateInput()
        {
            bool inputIsValid = true;
            int numberOfIssuesFound = 0;
            StringBuilder sb = new StringBuilder();
            if (textBoxTransliteratedStyle.Text.Trim() == "")
            {
                inputIsValid = false;
                numberOfIssuesFound++;
                sb.AppendLine("A style to apply to transliterated text is required");
            }
            if (comboBoxLanguageBlock.Text.Trim() == "")
            {
                inputIsValid = false;
                numberOfIssuesFound++;
                sb.AppendLine("A language box for transliteration is required");
            }
            else
            {
                Regex regEx = new Regex("");
                string pattern = Transliterate.DefaultSearchPattern(comboBoxLanguageBlock.Text, out patternValidity);
                switch(patternValidity)
                {
                    case Transliterate.PatternValidity.Valid:
                        break;
                    case Transliterate.PatternValidity.NotKnown:
                        inputIsValid = false;
                        break;
                    case Transliterate.PatternValidity.NeedsValidating:
                        if (regEx.IsValidPattern(pattern) == false)
                        {
                            inputIsValid = false;
                            numberOfIssuesFound++;
                            sb.AppendLine("Language block is not a valid unicode block");
                        }
                        break;
                    case Transliterate.PatternValidity.InvalidPattern:
                        inputIsValid = false;
                        break;
                }
            }
            if (textBoxOpeningDelimiter.Text.Trim() == "")
            {
                if (textBoxClosingDelimiter.Text.Trim() != "")
                {
                    sb.AppendLine("A closing delimiter has been provided without a matching opening delimeter.");
                    numberOfIssuesFound++;
                }
            }
            else
            {
                if (textBoxClosingDelimiter.Text.Trim() == "")
                {
                    sb.AppendLine("An opening delimiter has been provided without a matching closing delimeter.");
                    numberOfIssuesFound++;
                }
            }
            if (sb.ToString() != "")
            {
                sb.AppendLine("");
                if (inputIsValid)
                {
                    sb.AppendLine("Conversion will still take place");
                    numberOfIssuesFound++;
                }
                else
                {
                    if (numberOfIssuesFound == 1)
                        sb.AppendLine("Conversion will not take place until problem is fixed");
                    else
                        sb.AppendLine("Conversion will not take place until problems are fixed");
                }
            }
            if (numberOfIssuesFound > 0)
                MessageBox.Show(sb.ToString(), "Information");
            return inputIsValid;
        }

        private void resetAllValuesToDefaultValues()
        {
            string defaultSearchPattern = @"";
            Properties.Settings.Default.Size = new Size(610, 500);
            Properties.Settings.Default.Location = new Point(15, 15);
            Properties.Settings.Default.UpgradeRequired = true;
            Properties.Settings.Default.HideWelcomeMessage = false;
            Properties.Settings.Default.StyleToApplyToTransliteratedText = "TransliteratedText";
            Properties.Settings.Default.OpeningDelimiter = "{";
            Properties.Settings.Default.ClosingDelimiter = "}";
            Properties.Settings.Default.SearchPattern = defaultSearchPattern;
            if (Properties.Settings.Default.RecentFiles != null)
                Properties.Settings.Default.RecentFiles.Clear();
            Properties.Settings.Default.Save();
            applyDefaultValues();
        }

        private void applyDefaultValues()
        {
            Size = Properties.Settings.Default.Size;
            Location = Properties.Settings.Default.Location;
            WelcomeMessageInitialise();
            textBoxOpeningDelimiter.Text = Properties.Settings.Default.OpeningDelimiter;
            textBoxClosingDelimiter.Text = Properties.Settings.Default.ClosingDelimiter;
            comboBoxLanguageBlock.Text = Properties.Settings.Default.SearchPattern;
            textBoxTransliteratedStyle.Text = Properties.Settings.Default.StyleToApplyToTransliteratedText;
        }

        private string getInitialFileName()
        {
            string filename = "";
            if ((Properties.Settings.Default.RecentFiles != null) && (Properties.Settings.Default.RecentFiles.Count > 0))
                filename = Properties.Settings.Default.RecentFiles[Properties.Settings.Default.RecentFiles.Count - 1];
            if (filename == "")
            {
                openFileDialog.FileName = "";
            }
            else
            {
                openFileDialog.FileName = Path.GetFileName(filename);
                openFileDialog.InitialDirectory = Path.GetDirectoryName(filename);
            }
            openFileDialog.Filter = "docx files (*.docx)|*.docx";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                filename = openFileDialog.FileName;
                if (Properties.Settings.Default.RecentFiles == null)
                    Properties.Settings.Default.RecentFiles = new StringCollection();
                if (Properties.Settings.Default.RecentFiles.Contains(filename))
                {
                    Properties.Settings.Default.RecentFiles.Remove(filename);
                }

                while (Properties.Settings.Default.RecentFiles.Count > 5)
                {
                    Properties.Settings.Default.RecentFiles.RemoveAt(0);
                }
                Properties.Settings.Default.RecentFiles.Add(filename);
                Properties.Settings.Default.Save();
            }
            else
                filename = "";
            return filename;
        }

        private string getUpdatedFileName(string initialFileName)
        {
            string updatedFileName = initialFileName.Replace(".docx", " Updated.docx");
            saveFileDialog.FileName = Path.GetFileName(updatedFileName);
            saveFileDialog.InitialDirectory = Path.GetDirectoryName(updatedFileName);
            saveFileDialog.Filter = "Word document |*.docx";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
                updatedFileName = saveFileDialog.FileName;
            else
                updatedFileName = "";
            return updatedFileName;
        }

        private void hideMessageWhneOpeningApplicationNextTime()
        {
            Properties.Settings.Default.HideWelcomeMessage = checkBoxHideWelcomeMessage.Checked;
            Properties.Settings.Default.Save();
        }
    }

}
