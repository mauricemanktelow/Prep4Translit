﻿using System.Collections.Generic;
using System.Text;
using System;
using System.IO;
using System.Collections;
using System.Xml;
using System.Windows.Forms;
using mm.Extensions;
using mm.BackgroundWorkerNameSpace;
using mm.Utilities;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Word;
using System.Diagnostics;

namespace mm.Utilities
{
    /// <summary>
    /// Class <c>MicrosoftWordProcessing</c> contains methods to process to the xml within a Microsoft Word docx file
    /// </summary>
    public class MicrosoftWordProcessing
    {

        /// <summary>
        /// Method <c>MicrosoftWordProcessing()</c> initialise the class 
        /// </summary>
        public MicrosoftWordProcessing()
        {
        }
        public enum CheckResults { Notknown, EmptyString, StyleExists, StyleDoesNotExist}

        /// <summary>
        /// Method <c>CheckStyleExists</c> checks that the names style exists in the docx file
        /// </summary>
        /// <param name="documentFilename"></param>
        /// <param name="styleToCheck"></param>
        /// <returns></returns>
        public static CheckResults CheckStyleExists(string documentFilename, string styleToCheck, out string styleNameToApply)
        {
            CheckResults result = CheckResults.Notknown;
            styleNameToApply = "";
            string totalFileContentAsString = ParameterFileProcessing.GetString(documentFilename, @"word/styles.xml");
            if (totalFileContentAsString == "")
                result = CheckResults.EmptyString;
            else
            {
                string checkFor = @"w:styleId=""" + styleToCheck + @"""";
                if (totalFileContentAsString.Contains(checkFor))
                    result = CheckResults.StyleExists;
                else
                    result = CheckResults.StyleDoesNotExist;
                if (result == CheckResults.StyleExists)
                    styleNameToApply = getStyleNameToApply(totalFileContentAsString, styleToCheck);
            }
            return result;
        }

        private static string getStyleNameToApply(string allStylesSpecifications, string style)
        {
            var styleToSearchFor = @"w:styleId=""" + style + @"""";
            var styleSpecificationStartsAt = allStylesSpecifications.IndexOf(styleToSearchFor);
            styleSpecificationStartsAt = allStylesSpecifications.LastIndexOf(@"<w:style", styleSpecificationStartsAt);
            var styleSpecificationEndsAt = allStylesSpecifications.IndexOf(@"</w:style>", styleSpecificationStartsAt);
            string styleSpecificationToBeApplied = allStylesSpecifications.Substring(styleSpecificationStartsAt, styleSpecificationEndsAt - styleSpecificationStartsAt + 10);
            Match match = Regex.Match(styleSpecificationToBeApplied, @"(?<=w:link w:val="")([:=\s\p{L}]+)");
            if (match.Success)
                styleSpecificationToBeApplied = match.Value;
            else
                styleSpecificationToBeApplied = style;
            return styleSpecificationToBeApplied;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="workerParams"></param>
        /// <returns></returns>
        public static bool GetItemsFromFile(BackgroundWorkerParameters workerParams)
        {
            workerParams.OriginalDocumentTextAsXML = ParameterFileProcessing.GetString(workerParams.OriginalWordDocumentFileName, workerParams.IndividualFileNameInWordDocumentFile);
            workerParams.TransliterationCompletedSuccessfully = String.IsNullOrWhiteSpace(workerParams.OriginalDocumentTextAsXML) == false;
            return workerParams.TransliterationCompletedSuccessfully;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="xmlString"></param>
        /// <param name="textInDocument"></param>
        /// <returns></returns>
        public static XMLElement GetXMLElementsWhichMakeUpADocumentFromXMLString(string xmlString, out TextInDocument textInDocument)
        {
            textInDocument = new TextInDocument();
            int elementLevel = 1;
            int elementNo = 0;
            int index = 0;
            XMLElement currentElement = new XMLElement();
            XMLElement parentElement = createNewElement(ref elementLevel, ref elementNo, null, "Root", "", true, XMLElementTypes.Root);
            Stack stack = new Stack();
            try
            {
                using (XmlTextReader reader = new XmlTextReader(new StringReader(xmlString)))
                {
                    while (reader.Read())
                    {
                        switch (reader.NodeType)
                        {
                            case XmlNodeType.Element:
                                bool isEmptyElement = reader.IsEmptyElement;
                                elementNo = parentElement.ChildElements.Count;
                                currentElement = createNewElement(ref elementLevel, ref elementNo, parentElement, reader.Name, reader.Value, isEmptyElement, XMLElementTypes.StartElement);
                                getAttributes(currentElement, reader);
                                if (isEmptyElement)
                                {
                                    currentElement.Type = XMLElementTypes.Empty;
                                    parentElement.ChildElements.Add(currentElement);
                                }
                                else
                                {
                                    stack.Push(parentElement);
                                    parentElement = currentElement;
                                    elementLevel++;
                                }
                                break;
                            case XmlNodeType.EndElement:
                                elementLevel--;
                                currentElement = parentElement;
                                parentElement = stack.Pop() as XMLElement;
                                parentElement.ChildElements.Add(currentElement);
                                elementNo = parentElement.ChildElements.Count;
                                currentElement = createNewElement(ref elementLevel, ref elementNo, parentElement, reader.Name, reader.Value, reader.IsEmptyElement, XMLElementTypes.EndElement);
                                parentElement.ChildElements.Add(currentElement);
                                break;
                            case XmlNodeType.Text:
                                currentElement.Text = reader.Value;
                                currentElement.Type = XMLElementTypes.Content;
                                if (textInDocument.Items.Count > 0)
                                    index = textInDocument.Items[textInDocument.Items.Count - 1].IndexOfTextItem + textInDocument.Items[textInDocument.Items.Count - 1].Text.Length;
                                textInDocument.Items.Add(new TextItem(currentElement, index));
                                break;
                            case XmlNodeType.Whitespace:
                                break;
                            case XmlNodeType.SignificantWhitespace:
                                if (currentElement.Type != XMLElementTypes.Declaration)
                                {
                                    currentElement.Text = reader.Value;
                                    currentElement.Type = XMLElementTypes.WhiteSpace;
                                    if (textInDocument.Items.Count > 0)
                                        index = textInDocument.Items[textInDocument.Items.Count - 1].IndexOfTextItem + textInDocument.Items[textInDocument.Items.Count - 1].Text.Length;
                                    textInDocument.Items.Add(new TextItem(currentElement, index));
                                }
                                break;
                            case XmlNodeType.XmlDeclaration:
                                currentElement = createNewElement(ref elementLevel, ref elementNo, parentElement, reader.Name, reader.Value, reader.IsEmptyElement, XMLElementTypes.Declaration);
                                getAttributes(currentElement, reader);
                                parentElement.ChildElements.Add(currentElement);
                                break;
                            case XmlNodeType.Comment:
                                currentElement = createNewElement(ref elementLevel, ref elementNo, parentElement, reader.Name, reader.Value, reader.IsEmptyElement, XMLElementTypes.Comment);
                                parentElement.ChildElements.Add(currentElement);
                                break;
                        }
                    }
                    reader.Close();
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Error");
            }
            return parentElement;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="textElement"></param>
        /// <param name="elements"></param>
        /// <returns></returns>
        public static void InsertListOfElementsAfterATextElement(XMLElement textElement, List<XMLElement> elements)
        {
            XMLElement insertionPoint = textElement.Parent.Parent.ChildElements[textElement.Parent.ItemNo + 1];
            for (int index = elements.Count - 1; index > -1; index--)
            {
                textElement.Parent.Parent.ChildElements.Insert(textElement.Parent.ItemNo + 2, elements[index]);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="elementToCheck"></param>
        /// <returns></returns>
        public static bool IsElementOfTypeVanish(XMLElement elementToCheck)
        {
            bool elementIsOfTypeVanish = false;
            foreach (XMLElement element in elementToCheck.Parent.ChildElements)
            {
                if (element.Name == "w:rPr")
                {
                    if (element.ChildElements.Count > 0)
                    {
                        foreach (XMLElement nestedElement in element.ChildElements)
                        {
                            if (nestedElement.Name == "w:vanish")
                            {
                                elementIsOfTypeVanish = true;
                                break;
                            }
                        }
                    }
                }
            }
            return elementIsOfTypeVanish;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="elementToCheck"></param>
        /// <returns></returns>
        public static bool IsElementOfTypeRTL(XMLElement elementToCheck)
        {
            bool elementIsOfTypeVanish = false;
            foreach (XMLElement element in elementToCheck.Parent.ChildElements)
            {
                if (element.Name == "w:rPr")
                {
                    if (element.ChildElements.Count > 0)
                    {
                        foreach (XMLElement nestedElement in element.ChildElements)
                        {
                            if (nestedElement.Name == "w:rtl")
                            {
                                elementIsOfTypeVanish = true;
                                break;
                            }
                        }
                    }
                }
            }
            return elementIsOfTypeVanish;
        }

        private static string getAttributes(XMLElement element, XmlTextReader reader)
        {
            StringBuilder sb = new StringBuilder();
            for (int attributeIndex = 0; attributeIndex < reader.AttributeCount; attributeIndex++)
            {
                reader.MoveToAttribute(attributeIndex);
                string attribute = reader.Value;
                element.Attributes.Add(new XMLAttribute(reader.Name, attribute));
            }
            return sb.ToString();
        }

        private static XMLElement createNewElement(ref int elementID, ref int elementNo, XMLElement parentElement, string name, string value, bool isEmptyElement, XMLElementTypes type)
        {
            XMLElement currentElement = new XMLElement(elementID, elementNo, name, value, type);
            currentElement.Parent = parentElement;
            currentElement.IsEmptyElement = isEmptyElement;
            currentElement.Type = type;
            currentElement.Text = value;
            return currentElement;
        }
    }
}

/// <summary>
/// 
/// </summary>
public class TextInDocument
{
    public string text;
    public string Text
    {
        get
        {
            if (text == "")
            {
                for (int index = 0; index < Items.Count; index++)
                {
                    string elementText = Items[index].Text;
                    if (elementText != "")
                    {
                        text += Items[index].Text;
                    }
                }
            }
            return text;
        }
    }
    private List<TextItem> index;
    public List<TextItem> Index
    {
        get
        {
            if (index == null)
            {
                index = new List<TextItem>(Text.Length);
                foreach (TextItem anItem in Items)
                {
                    for (int index2 = 0; index2 < anItem.Text.Length; index2++)
                    {
                        index.Add(anItem);
                    }
                }
            }
            return index;
        }
    }

    public List<TextItem> Items;
    public XMLElement Elements;

    /// <summary>
    /// This constructor initialises the <c>TextInDocument</c> object
    /// </summary>
    public TextInDocument()
    {
        text = "";
        Items = new List<TextItem>();
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        foreach (TextItem item in Items)
        {
            sb.AppendLine(XMLElement.ReplaceXMLReservedCharactersWithCharacterString(item.Text));
        }
        return sb.ToString();
    }
}

/// <summary>
/// Class <c>TextItem</c> contains a number of properties of a particualr item of text in teh document
/// </summary>
public class TextItem
{
    /// <summary>
    /// Property <c>Text</c> returns the text in the current text item
    /// </summary>
    public string Text
    {
        get { return TextElement.Text; }
    }

    /// <summary>
    /// Property <c>ElementID</c> returns the ID of the current text item
    /// </summary>
    public string ElementID
    {
        get
        {
            return TextElement.ID;
        }
    }

    /// <summary>
    /// Property <c>TextElement</c> returns the index of the current TextItem in collection of elements comprising the document.
    /// </summary>
    public readonly int IndexOfTextItem;

    /// <summary>
    /// Property <c>TextElement</c> returns the XML text element associated with the current text item
    /// </summary>
    public readonly XMLElement TextElement;

    private List<StringUnicodeValues> unicodeValues;
    /// <summary>
    /// Property <c>UnicodeValues</c> contain a list of Unicode values of a string.
    /// </summary>
    public List<StringUnicodeValues> UnicodeValues
    {
        get
        {
            if (unicodeValues == null)
                unicodeValues = TextElement.Text.GetUnicodeValues();
            return unicodeValues;
        }
    }

    /// <summary>
    /// Initialises a new <c>TextItem</c>
    /// </summary>
    /// <param name="element"></param>
    /// <param name="indexOfTextItem"></param>
    public TextItem(XMLElement element, int indexOfTextItem)
    {
        IndexOfTextItem = indexOfTextItem;
        TextElement = element;
    }
}

/// <summary>
/// Enumerated type <c>XMLElementTypes</c> identifies the type of content of an XML element. 
/// </summary>
public enum XMLElementTypes
{
    /// <summary>
    /// identifies the root element of the XML tree
    /// </summary>
    Root,
    /// <summary>
    /// identifies a declaration type element
    /// </summary>
    Declaration,
    /// <summary>
    /// identifies a text element
    /// </summary>
    Content,
    /// <summary>
    /// identifies a text element containing only white space
    /// </summary>
    WhiteSpace,
    /// <summary>
    /// identifies an element containing a comment
    /// </summary>
    Comment,
    /// <summary>
    /// identifies the start of a text element
    /// </summary>
    StartElement,
    /// <summary>
    /// identifies the end of a text element
    /// </summary>
    EndElement,
    /// <summary>
    /// idenitifies an empty element
    /// </summary>
    Empty
}

/// <summary>
/// 
/// </summary>
public enum XMLElementDirectionality
{
    /// <summary>
    /// 
    /// </summary>
    UnKown,
    /// <summary>
    /// 
    /// </summary>
    LeftToRight,
    /// <summary>
    /// 
    /// </summary>
    RightToLeft
}

/// <summary>
/// Class <c>XMLElement</c> Provides a method of storing an XML element which is part of the xml file
/// </summary>
public class XMLElement : ICloneable
{
    /// <summary>
    /// 
    /// </summary>
    public XMLElementTypes Type;
    /// <summary>
    /// 
    /// </summary>
    public string Name;
    /// <summary>
    /// 
    /// </summary>
    public List<XMLAttribute> Attributes;
    private string text;
    /// <summary>
    /// 
    /// </summary>
    public string Text
    {
        get { return ReplaceXMLReservedCharactersWithCharacterString(text); }
        set { text = value; }
    }
    /// <summary>
    /// 
    /// </summary>
    public List<XMLElement> ChildElements;
    /// <summary>
    /// 
    /// </summary>
    public bool IsEmptyElement;
    /// <summary>
    /// 
    /// </summary>
    public XMLElement Parent = null;
    /// <summary>
    /// 
    /// </summary>
    public int Level;
    /// <summary>
    /// 
    /// </summary>
    public int ItemNo;
    /// <summary>
    /// 
    /// </summary>
    public string ID { get { return Level + "." + ItemNo; } }
    /// <summary>
    /// 
    /// </summary>
    public XMLElementDirectionality Directionality
    {
        get
        {
            XMLElementDirectionality directionality = XMLElementDirectionality.UnKown;
            if (Parent != null)
            {
                foreach (XMLElement element in Parent.ChildElements)
                {
                    if (element.Name == "w:rPr")
                    {
                        foreach (XMLElement childElement in element.ChildElements)
                        {
                            if (childElement.Name == "w:rtl")
                            {
                                directionality = XMLElementDirectionality.RightToLeft;
                                break;
                            }
                        }
                    }
                    if (directionality != XMLElementDirectionality.UnKown)
                        break;
                }
            }
            if (directionality == XMLElementDirectionality.UnKown)
                directionality = XMLElementDirectionality.LeftToRight;
            return directionality;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public object Clone()
    {
        XMLElement clone = new XMLElement();
        clone.Type = Type;
        clone.Name = Name;
        foreach (XMLAttribute anAttribute in Attributes)
            clone.Attributes.Add((XMLAttribute)anAttribute.Clone());
        clone.Text = Text;
        foreach (XMLElement anElement in ChildElements)
            clone.ChildElements.Add((XMLElement)anElement.Clone());
        clone.IsEmptyElement = IsEmptyElement;
        clone.Parent = null;
        clone.Level = Level;
        clone.ItemNo = ItemNo;
        return clone;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="level"></param>
    /// <param name="itemNo"></param>
    /// <param name="name"></param>
    /// <param name="value"></param>
    /// <param name="type"></param>
    /// <param name="text"></param>
    /// <param name="isEmptyElement"></param>
    public XMLElement(int level, int itemNo, string name, string value, XMLElementTypes type, string text, bool isEmptyElement)
    {
        Level = level;
        ItemNo = itemNo;
        Name = name;
        Attributes = new List<XMLAttribute>();
        Text = text;
        ChildElements = new List<XMLElement>();
        Type = type;
        IsEmptyElement = isEmptyElement;
        Text = value;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="level"></param>
    /// <param name="itemNo"></param>
    /// <param name="name"></param>
    /// <param name="value"></param>
    /// <param name="type"></param>
    /// <param name="isEmptyElement"></param>
    public XMLElement(int level, int itemNo, string name, string value, XMLElementTypes type, bool isEmptyElement)
    {
        Level = level;
        ItemNo = itemNo;
        Name = name;
        Attributes = new List<XMLAttribute>();
        Text = "";
        ChildElements = new List<XMLElement>();
        Type = type;
        IsEmptyElement = isEmptyElement;
        Text = value;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="level"></param>
    /// <param name="itemNo"></param>
    /// <param name="name"></param>
    /// <param name="value"></param>
    /// <param name="type"></param>
    public XMLElement(int level, int itemNo, string name, string value, XMLElementTypes type)
    {
        Level = level;
        ItemNo = itemNo;
        Name = name;
        Attributes = new List<XMLAttribute>();
        Text = "";
        ChildElements = new List<XMLElement>();
        Type = type;
        IsEmptyElement = true;
        Text = value;
    }

    /// <summary>
    /// 
    /// </summary>
    public XMLElement()
    {
        Level = 0;
        ItemNo = 0;
        Name = "root";
        Attributes = new List<XMLAttribute>();
        Text = "";
        ChildElements = new List<XMLElement>();
        Type = XMLElementTypes.Root;
        IsEmptyElement = true;
        Type = XMLElementTypes.Root;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public XMLElement Copy()
    {
        XMLElement copy = new XMLElement();
        copy.Type = Type;
        copy.Name = Name;
        copy.Text = Text;
        copy.IsEmptyElement = IsEmptyElement;
        copy.Parent = Parent;
        copy.ItemNo = ItemNo;
        copy.Level = Level;
        foreach (XMLAttribute anAttrribute in Attributes)
            copy.Attributes.Add(anAttrribute);
        foreach (XMLElement aChildElement in ChildElements)
            copy.ChildElements.Add(aChildElement);
        return copy;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="style"></param>
    /// <returns></returns>
    public bool ReplaceStyle(string style)
    {
        bool styleHasBeenUpdated = false;
        for (int index = 0; index < ChildElements.Count; index++)
        {
            XMLElement element = ChildElements[index];
            if (element.Name == "w:rPr")
            {
                foreach (XMLElement childElement in element.ChildElements)
                {
                    if (childElement.Name == "w:rStyle")
                    {
                        for (int index2 = 0; index < childElement.Attributes.Count; index++)
                        {
                            if (childElement.Attributes[index].Name == "w:val")
                            {
                                childElement.Attributes.RemoveAt(index2);
                                childElement.Attributes.Add(new XMLAttribute("w:val", style));
                                styleHasBeenUpdated = true;
                                break;
                            }
                        }
                    }
                }
                if (styleHasBeenUpdated == false)
                {
                    XMLElement newElement = new XMLElement();
                    newElement.Name = "w:rStyle";
                    newElement.Type = XMLElementTypes.Empty;
                    newElement.Attributes.Add(new XMLAttribute("w:val", style));
                    element.ChildElements.Add(newElement);
                }
                break;
            }
        }
        return styleHasBeenUpdated;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="text"></param>
    /// <returns></returns>
    public static string ReplaceXMLReservedCharactersWithCharacterString(string text)
    {
        string originalText = text;
        if (text.Contains("&"))
            text = text.Replace("&", "&amp;");
        if (text.Contains("<"))
            text = text.Replace("<", "&lt;");
        if (text.Contains(">"))
            text = text.Replace(">", "&gt;");
        return text;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public override string ToString()
    {
        string openingBracket = "";
        string closingBracket = "";
        string attributes = "";
        string content = "";
        StringBuilder sb = new StringBuilder();
        switch (Type)
        {
            case XMLElementTypes.StartElement:
                openingBracket = "<";
                closingBracket = ">";
                attributes = getAttributes();
                sb.Append(Text);
                foreach (XMLElement childElement in ChildElements)
                {
                    string str = childElement.ToString();
                    sb.Append(str);
                }
                content = sb.ToString();
                break;
            case XMLElementTypes.Empty:
                openingBracket = "<";
                closingBracket = "/>";
                attributes = getAttributes();
                sb.Append(Text);
                foreach (XMLElement childElement in ChildElements)
                    sb.Append(childElement.ToString());
                content = sb.ToString();
                break;
            case XMLElementTypes.Comment:
            case XMLElementTypes.Content:
                openingBracket = "<";
                if (IsEmptyElement)
                    closingBracket = "/>";
                else
                    closingBracket = ">";
                attributes = getAttributes();
                sb.Append(Text);
                foreach (XMLElement childElement in ChildElements)
                    sb.Append(childElement.ToString());
                content = sb.ToString();
                break;
            case XMLElementTypes.Declaration:
                openingBracket = "<?";
                closingBracket = "?>";
                attributes = getAttributes();
                break;
            case XMLElementTypes.EndElement:
                openingBracket = "</";
                closingBracket = ">";
                break;
            case XMLElementTypes.Root:
                foreach (XMLElement childElement in ChildElements)
                    sb.Append(childElement.ToString());
                content = sb.ToString();
                break;
            case XMLElementTypes.WhiteSpace:
                openingBracket = "<";
                closingBracket = ">";
                attributes = getAttributes();
                sb.Append(Text);
                foreach (XMLElement childElement in ChildElements)
                {
                    string str = childElement.ToString();
                    sb.Append(str);
                }
                content = sb.ToString();
                break;
            default:
                break;

        }
        if (Name == "Root")
            return content;
        else
        {
            return openingBracket + Name + attributes + closingBracket + content;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public bool ContainsSpaceElement()
    {
        bool containsSpaces = false;
        foreach (XMLElement child in ChildElements)
        {
            containsSpaces = containsSpaces || child.ContainsSpaceElement();
        }
        containsSpaces = containsSpaces || Text.IsSpaces();
        return containsSpaces;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public bool ContainsRightToLeftSpaceElement()
    {
        bool containsSpaces = false;
        foreach (XMLElement child in ChildElements)
        {
            containsSpaces = containsSpaces || child.ContainsRightToLeftSpaceElement();
        }
        if (Directionality == XMLElementDirectionality.RightToLeft)
            containsSpaces = containsSpaces || Text.IsSpaces();
        return containsSpaces;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public string GetContent()
    {
        string content = "";
        foreach (XMLElement child in ChildElements)
        {
            if (child.Name == "w:t")
                content += child.GetContent();
        }
        content += Text;
        return content;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public bool ContainsDirectionMarker()
    {
        bool containsSpaceElement = false;
        foreach (XMLElement child in ChildElements)
        {
            containsSpaceElement = containsSpaceElement || child.ContainsDirectionMarker();
        }
        if (Text.Length == 1)
            containsSpaceElement = containsSpaceElement || Unicode.IsDirectionMarker(Text[0]);
        return containsSpaceElement;
    }

    private string getAttributes()
    {
        StringBuilder sb = new StringBuilder();
        foreach (XMLAttribute attribute in Attributes)
            sb.Append(" " + attribute.ToString());
        return sb.ToString();
    }
}

/// <summary>
/// 
/// </summary>
public struct XMLAttribute : ICloneable
{
    /// <summary>
    /// 
    /// </summary>
    public string Name;
    /// <summary>
    /// 
    /// </summary>
    public string Value;
    /// <summary>
    /// 
    /// </summary>
    /// <param name="name"></param>
    /// <param name="value"></param>
    public XMLAttribute(string name, string value)
    {
        Name = name;
        Value = value;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public override string ToString()
    {
        return Name + @"=""" + Value + @"""";
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public object Clone()
    {
        return MemberwiseClone();
    }
}




