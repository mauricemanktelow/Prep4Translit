﻿namespace Prep4Translit
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelFileName = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.tabControlMain = new System.Windows.Forms.TabControl();
            this.tabPageWelcome = new System.Windows.Forms.TabPage();
            this.splitContainerWelcomeTab = new System.Windows.Forms.SplitContainer();
            this.webBrowserWelcomeMessage = new System.Windows.Forms.WebBrowser();
            this.checkBoxHideWelcomeMessage = new System.Windows.Forms.CheckBox();
            this.tabPageGetParameters = new System.Windows.Forms.TabPage();
            this.labelStylePreviouslyDefined = new System.Windows.Forms.Label();
            this.labelExample = new System.Windows.Forms.Label();
            this.comboBoxLanguageBlock = new System.Windows.Forms.ComboBox();
            this.buttonClose = new System.Windows.Forms.Button();
            this.textBoxClosingDelimiter = new System.Windows.Forms.TextBox();
            this.textBoxOpeningDelimiter = new System.Windows.Forms.TextBox();
            this.labelClosingDelimiter = new System.Windows.Forms.Label();
            this.labelOpeningDelimiter = new System.Windows.Forms.Label();
            this.labelNumberOfInsertions = new System.Windows.Forms.Label();
            this.textBoxTransliteratedStyle = new System.Windows.Forms.TextBox();
            this.labelTransliteratiedStyle = new System.Windows.Forms.Label();
            this.labelLanguageBlockForTransliteration = new System.Windows.Forms.Label();
            this.buttonRunNow = new System.Windows.Forms.Button();
            this.richTextBoxMain = new System.Windows.Forms.RichTextBox();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontDialog = new System.Windows.Forms.FontDialog();
            this.printDialog = new System.Windows.Forms.PrintDialog();
            this.printDocument = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
            this.pageSetupDialog = new System.Windows.Forms.PageSetupDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.backgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.toolStripContainer1.BottomToolStripPanel.SuspendLayout();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.tabControlMain.SuspendLayout();
            this.tabPageWelcome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerWelcomeTab)).BeginInit();
            this.splitContainerWelcomeTab.Panel1.SuspendLayout();
            this.splitContainerWelcomeTab.Panel2.SuspendLayout();
            this.splitContainerWelcomeTab.SuspendLayout();
            this.tabPageGetParameters.SuspendLayout();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.BottomToolStripPanel
            // 
            this.toolStripContainer1.BottomToolStripPanel.Controls.Add(this.statusStrip);
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.tabControlMain);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(601, 271);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(601, 317);
            this.toolStripContainer1.TabIndex = 0;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.menuStrip);
            // 
            // statusStrip
            // 
            this.statusStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelFileName,
            this.toolStripProgressBar});
            this.statusStrip.Location = new System.Drawing.Point(0, 0);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(601, 22);
            this.statusStrip.TabIndex = 0;
            // 
            // toolStripStatusLabelFileName
            // 
            this.toolStripStatusLabelFileName.Name = "toolStripStatusLabelFileName";
            this.toolStripStatusLabelFileName.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabelFileName.Text = "toolStripStatusLabel1";
            // 
            // toolStripProgressBar
            // 
            this.toolStripProgressBar.Name = "toolStripProgressBar";
            this.toolStripProgressBar.Size = new System.Drawing.Size(100, 16);
            // 
            // tabControlMain
            // 
            this.tabControlMain.Controls.Add(this.tabPageWelcome);
            this.tabControlMain.Controls.Add(this.tabPageGetParameters);
            this.tabControlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlMain.Location = new System.Drawing.Point(0, 0);
            this.tabControlMain.Name = "tabControlMain";
            this.tabControlMain.SelectedIndex = 0;
            this.tabControlMain.Size = new System.Drawing.Size(601, 271);
            this.tabControlMain.TabIndex = 0;
            // 
            // tabPageWelcome
            // 
            this.tabPageWelcome.Controls.Add(this.splitContainerWelcomeTab);
            this.tabPageWelcome.Location = new System.Drawing.Point(4, 22);
            this.tabPageWelcome.Name = "tabPageWelcome";
            this.tabPageWelcome.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageWelcome.Size = new System.Drawing.Size(593, 245);
            this.tabPageWelcome.TabIndex = 0;
            this.tabPageWelcome.Text = "Welcome";
            this.tabPageWelcome.UseVisualStyleBackColor = true;
            // 
            // splitContainerWelcomeTab
            // 
            this.splitContainerWelcomeTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerWelcomeTab.Location = new System.Drawing.Point(3, 3);
            this.splitContainerWelcomeTab.Name = "splitContainerWelcomeTab";
            this.splitContainerWelcomeTab.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainerWelcomeTab.Panel1
            // 
            this.splitContainerWelcomeTab.Panel1.Controls.Add(this.webBrowserWelcomeMessage);
            // 
            // splitContainerWelcomeTab.Panel2
            // 
            this.splitContainerWelcomeTab.Panel2.Controls.Add(this.checkBoxHideWelcomeMessage);
            this.splitContainerWelcomeTab.Size = new System.Drawing.Size(587, 239);
            this.splitContainerWelcomeTab.SplitterDistance = 208;
            this.splitContainerWelcomeTab.TabIndex = 1;
            // 
            // webBrowserWelcomeMessage
            // 
            this.webBrowserWelcomeMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowserWelcomeMessage.Location = new System.Drawing.Point(0, 0);
            this.webBrowserWelcomeMessage.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowserWelcomeMessage.Name = "webBrowserWelcomeMessage";
            this.webBrowserWelcomeMessage.Size = new System.Drawing.Size(587, 208);
            this.webBrowserWelcomeMessage.TabIndex = 0;
            // 
            // checkBoxHideWelcomeMessage
            // 
            this.checkBoxHideWelcomeMessage.AutoSize = true;
            this.checkBoxHideWelcomeMessage.Dock = System.Windows.Forms.DockStyle.Right;
            this.checkBoxHideWelcomeMessage.Location = new System.Drawing.Point(435, 0);
            this.checkBoxHideWelcomeMessage.Name = "checkBoxHideWelcomeMessage";
            this.checkBoxHideWelcomeMessage.Size = new System.Drawing.Size(152, 27);
            this.checkBoxHideWelcomeMessage.TabIndex = 0;
            this.checkBoxHideWelcomeMessage.Text = "Hide message in the future";
            this.checkBoxHideWelcomeMessage.UseVisualStyleBackColor = true;
            this.checkBoxHideWelcomeMessage.CheckedChanged += new System.EventHandler(this.checkBoxHideWelcomeMessage_CheckedChanged);
            // 
            // tabPageGetParameters
            // 
            this.tabPageGetParameters.Controls.Add(this.labelStylePreviouslyDefined);
            this.tabPageGetParameters.Controls.Add(this.labelExample);
            this.tabPageGetParameters.Controls.Add(this.comboBoxLanguageBlock);
            this.tabPageGetParameters.Controls.Add(this.buttonClose);
            this.tabPageGetParameters.Controls.Add(this.textBoxClosingDelimiter);
            this.tabPageGetParameters.Controls.Add(this.textBoxOpeningDelimiter);
            this.tabPageGetParameters.Controls.Add(this.labelClosingDelimiter);
            this.tabPageGetParameters.Controls.Add(this.labelOpeningDelimiter);
            this.tabPageGetParameters.Controls.Add(this.labelNumberOfInsertions);
            this.tabPageGetParameters.Controls.Add(this.textBoxTransliteratedStyle);
            this.tabPageGetParameters.Controls.Add(this.labelTransliteratiedStyle);
            this.tabPageGetParameters.Controls.Add(this.labelLanguageBlockForTransliteration);
            this.tabPageGetParameters.Controls.Add(this.buttonRunNow);
            this.tabPageGetParameters.Controls.Add(this.richTextBoxMain);
            this.tabPageGetParameters.Location = new System.Drawing.Point(4, 22);
            this.tabPageGetParameters.Name = "tabPageGetParameters";
            this.tabPageGetParameters.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageGetParameters.Size = new System.Drawing.Size(593, 245);
            this.tabPageGetParameters.TabIndex = 1;
            this.tabPageGetParameters.Text = "Get Parameters";
            this.tabPageGetParameters.UseVisualStyleBackColor = true;
            // 
            // labelStylePreviouslyDefined
            // 
            this.labelStylePreviouslyDefined.AutoSize = true;
            this.labelStylePreviouslyDefined.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStylePreviouslyDefined.Location = new System.Drawing.Point(255, 109);
            this.labelStylePreviouslyDefined.Name = "labelStylePreviouslyDefined";
            this.labelStylePreviouslyDefined.Size = new System.Drawing.Size(271, 12);
            this.labelStylePreviouslyDefined.TabIndex = 15;
            this.labelStylePreviouslyDefined.Text = "Must have been previously defined in the original Word document";
            // 
            // labelExample
            // 
            this.labelExample.AutoSize = true;
            this.labelExample.Location = new System.Drawing.Point(255, 67);
            this.labelExample.Name = "labelExample";
            this.labelExample.Size = new System.Drawing.Size(35, 13);
            this.labelExample.TabIndex = 14;
            this.labelExample.Text = "label1";
            // 
            // comboBoxLanguageBlock
            // 
            this.comboBoxLanguageBlock.FormattingEnabled = true;
            this.comboBoxLanguageBlock.Items.AddRange(new object[] {
            "Arabic",
            "Greek",
            "Hebrew",
            "Syriac",
            "Other"});
            this.comboBoxLanguageBlock.Location = new System.Drawing.Point(235, 42);
            this.comboBoxLanguageBlock.Name = "comboBoxLanguageBlock";
            this.comboBoxLanguageBlock.Size = new System.Drawing.Size(142, 21);
            this.comboBoxLanguageBlock.TabIndex = 13;
            this.comboBoxLanguageBlock.TextChanged += new System.EventHandler(this.comboBoxLanguageBlock_TextChanged);
            // 
            // buttonClose
            // 
            this.buttonClose.Location = new System.Drawing.Point(403, 210);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(154, 23);
            this.buttonClose.TabIndex = 11;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // textBoxClosingDelimiter
            // 
            this.textBoxClosingDelimiter.Location = new System.Drawing.Point(235, 159);
            this.textBoxClosingDelimiter.Name = "textBoxClosingDelimiter";
            this.textBoxClosingDelimiter.Size = new System.Drawing.Size(28, 20);
            this.textBoxClosingDelimiter.TabIndex = 10;
            // 
            // textBoxOpeningDelimiter
            // 
            this.textBoxOpeningDelimiter.Location = new System.Drawing.Point(235, 133);
            this.textBoxOpeningDelimiter.Name = "textBoxOpeningDelimiter";
            this.textBoxOpeningDelimiter.Size = new System.Drawing.Size(28, 20);
            this.textBoxOpeningDelimiter.TabIndex = 9;
            // 
            // labelClosingDelimiter
            // 
            this.labelClosingDelimiter.AutoSize = true;
            this.labelClosingDelimiter.Location = new System.Drawing.Point(29, 162);
            this.labelClosingDelimiter.Name = "labelClosingDelimiter";
            this.labelClosingDelimiter.Size = new System.Drawing.Size(126, 13);
            this.labelClosingDelimiter.TabIndex = 8;
            this.labelClosingDelimiter.Text = "Closing delimeter to apply";
            // 
            // labelOpeningDelimiter
            // 
            this.labelOpeningDelimiter.AutoSize = true;
            this.labelOpeningDelimiter.Location = new System.Drawing.Point(29, 136);
            this.labelOpeningDelimiter.Name = "labelOpeningDelimiter";
            this.labelOpeningDelimiter.Size = new System.Drawing.Size(128, 13);
            this.labelOpeningDelimiter.TabIndex = 7;
            this.labelOpeningDelimiter.Text = "Opening delimiter to apply";
            // 
            // labelNumberOfInsertions
            // 
            this.labelNumberOfInsertions.AutoSize = true;
            this.labelNumberOfInsertions.Location = new System.Drawing.Point(29, 210);
            this.labelNumberOfInsertions.Name = "labelNumberOfInsertions";
            this.labelNumberOfInsertions.Size = new System.Drawing.Size(168, 13);
            this.labelNumberOfInsertions.TabIndex = 6;
            this.labelNumberOfInsertions.Text = "Number of transliteration insertions";
            // 
            // textBoxTransliteratedStyle
            // 
            this.textBoxTransliteratedStyle.Location = new System.Drawing.Point(235, 86);
            this.textBoxTransliteratedStyle.Name = "textBoxTransliteratedStyle";
            this.textBoxTransliteratedStyle.Size = new System.Drawing.Size(142, 20);
            this.textBoxTransliteratedStyle.TabIndex = 5;
            // 
            // labelTransliteratiedStyle
            // 
            this.labelTransliteratiedStyle.AutoSize = true;
            this.labelTransliteratiedStyle.Location = new System.Drawing.Point(29, 89);
            this.labelTransliteratiedStyle.Name = "labelTransliteratiedStyle";
            this.labelTransliteratiedStyle.Size = new System.Drawing.Size(199, 13);
            this.labelTransliteratiedStyle.TabIndex = 4;
            this.labelTransliteratiedStyle.Text = "Style to apply to transliterate inserted text";
            // 
            // labelLanguageBlockForTransliteration
            // 
            this.labelLanguageBlockForTransliteration.AutoSize = true;
            this.labelLanguageBlockForTransliteration.Location = new System.Drawing.Point(29, 42);
            this.labelLanguageBlockForTransliteration.Name = "labelLanguageBlockForTransliteration";
            this.labelLanguageBlockForTransliteration.Size = new System.Drawing.Size(164, 13);
            this.labelLanguageBlockForTransliteration.TabIndex = 2;
            this.labelLanguageBlockForTransliteration.Text = "Language block for transliteration";
            // 
            // buttonRunNow
            // 
            this.buttonRunNow.Location = new System.Drawing.Point(403, 152);
            this.buttonRunNow.Name = "buttonRunNow";
            this.buttonRunNow.Size = new System.Drawing.Size(154, 23);
            this.buttonRunNow.TabIndex = 1;
            this.buttonRunNow.Text = "Run conversion now";
            this.buttonRunNow.UseVisualStyleBackColor = true;
            this.buttonRunNow.Click += new System.EventHandler(this.buttonRunNow_Click);
            // 
            // richTextBoxMain
            // 
            this.richTextBoxMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBoxMain.Location = new System.Drawing.Point(3, 3);
            this.richTextBoxMain.Name = "richTextBoxMain";
            this.richTextBoxMain.Size = new System.Drawing.Size(587, 239);
            this.richTextBoxMain.TabIndex = 0;
            this.richTextBoxMain.Text = "";
            // 
            // menuStrip
            // 
            this.menuStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resetToolStripMenuItem,
            this.aboutToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(601, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip1";
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.resetToolStripMenuItem.Text = "&Reset";
            this.resetToolStripMenuItem.ToolTipText = "Reset all values to their intial / default value";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "&About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.closeToolStripMenuItem.Text = "&Close";
            this.closeToolStripMenuItem.ToolTipText = "Close progamme";
            // 
            // printDialog
            // 
            this.printDialog.AllowSelection = true;
            this.printDialog.AllowSomePages = true;
            this.printDialog.Document = this.printDocument;
            this.printDialog.UseEXDialog = true;
            // 
            // printPreviewDialog
            // 
            this.printPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog.Document = this.printDocument;
            this.printPreviewDialog.Enabled = true;
            this.printPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog.Icon")));
            this.printPreviewDialog.Name = "printPreviewDialog";
            this.printPreviewDialog.UseAntiAlias = true;
            this.printPreviewDialog.Visible = false;
            // 
            // pageSetupDialog
            // 
            this.pageSetupDialog.Document = this.printDocument;
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            // 
            // backgroundWorker
            // 
            this.backgroundWorker.WorkerReportsProgress = true;
            this.backgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker_DoWork);
            this.backgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker_ProgressChanged);
            this.backgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker_RunWorkerCompleted);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 317);
            this.Controls.Add(this.toolStripContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FormMain";
            this.Text = "Easy-Transliterate";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStripContainer1.BottomToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.BottomToolStripPanel.PerformLayout();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.tabControlMain.ResumeLayout(false);
            this.tabPageWelcome.ResumeLayout(false);
            this.splitContainerWelcomeTab.Panel1.ResumeLayout(false);
            this.splitContainerWelcomeTab.Panel2.ResumeLayout(false);
            this.splitContainerWelcomeTab.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerWelcomeTab)).EndInit();
            this.splitContainerWelcomeTab.ResumeLayout(false);
            this.tabPageGetParameters.ResumeLayout(false);
            this.tabPageGetParameters.PerformLayout();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.FontDialog fontDialog;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.PrintDialog printDialog;
        private System.Windows.Forms.PageSetupDialog pageSetupDialog;
        public System.Windows.Forms.PrintPreviewDialog printPreviewDialog;
        public System.Drawing.Printing.PrintDocument printDocument;
        private System.Windows.Forms.TabControl tabControlMain;
        private System.Windows.Forms.TabPage tabPageWelcome;
        private System.Windows.Forms.SplitContainer splitContainerWelcomeTab;
        private System.Windows.Forms.WebBrowser webBrowserWelcomeMessage;
        private System.Windows.Forms.CheckBox checkBoxHideWelcomeMessage;
        private System.Windows.Forms.TabPage tabPageGetParameters;
        public System.Windows.Forms.RichTextBox richTextBoxMain;
        private System.Windows.Forms.Button buttonRunNow;
        private System.Windows.Forms.Label labelLanguageBlockForTransliteration;
        private System.Windows.Forms.TextBox textBoxTransliteratedStyle;
        private System.Windows.Forms.Label labelTransliteratiedStyle;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Label labelNumberOfInsertions;
        private System.Windows.Forms.TextBox textBoxClosingDelimiter;
        private System.Windows.Forms.TextBox textBoxOpeningDelimiter;
        private System.Windows.Forms.Label labelClosingDelimiter;
        private System.Windows.Forms.Label labelOpeningDelimiter;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelFileName;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar;
        private System.ComponentModel.BackgroundWorker backgroundWorker;
        public System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ComboBox comboBoxLanguageBlock;
        private System.Windows.Forms.Label labelExample;
        private System.Windows.Forms.Label labelStylePreviouslyDefined;
    }
}

