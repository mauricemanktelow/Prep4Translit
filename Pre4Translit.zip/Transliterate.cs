﻿using mm.Utilities;
using System.Text.RegularExpressions;
using System;
using System.Collections.Generic;
using mm.Extensions;
using mm.BackgroundWorkerNameSpace;
using System.Windows.Forms;
using System.Text;
using System.IO;


namespace TransliterateNameSpace
{
    /// <summary>
    /// Class <c>Transliterate</c> processes the Document xml string extract from a Microsft Word document (docx) file and inserts duplicate text for subsequent transliteration 
    /// </summary>
    public class Transliterate
    {
        //       public const string DefaultSearchPattern =
        //@"(\([\u0370-\u03FF\u1F00-\u1FFF\u0342-\u0345\u2019\u0590-\u05ff\u202A\u202C\u200E\u200F]+\))*([\u0370-\u03FF\u1F00-\u1FFF\u0342-\u0345\u2019\u0590-\u05ff\u202A\u202C\u200E\u200F]+)([\s\u202A\u202C\u200E\u200F\u2026\u2025\u002E{2,3}\u002D\u2011\u2012\u2013\u2014]*([\u0370-\u03FF\u1F00-\u1FFF\u0342-\u0345\u2019\u0590-\u05ff]+[\u202A\u202C\u200E\u200F]*)+)+(\s*\([\u0370-\u03FF\u1F00-\u1FFF\u0342-\u0345\u2019\u0590-\u05ff\u002D\u2011\u2012\u2013\u2014]+\))*";

        public enum PatternValidity { NotKnown, Valid, NeedsValidating, InvalidPattern }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="languageBlock"></param>
        /// <returns></returns>
        public static string DefaultSearchPattern(string languageSet, out PatternValidity patternNeedsValidating)
        {
            patternNeedsValidating = PatternValidity.NotKnown;
            string pattern = "";
            StringBuilder sb = new StringBuilder();
            switch (languageSet.Trim())
            {
                case "Arabic":
                    pattern = getPattern(@"\u0600-\u06FF");
                    patternNeedsValidating = PatternValidity.Valid;
                    break;
                case "Greek":
                    pattern = getPattern(@"\u0370-\u03FF\u1F00-\u1FFE\u0342-\u0345");
                    patternNeedsValidating = PatternValidity.Valid;
                    break;
                case "Hebrew":
                    pattern = getPattern(@"\u0590-\u05FF");
                    patternNeedsValidating = PatternValidity.Valid;
                    break;
                case "Syriac":
                    pattern = getPattern(@"\u0700-\u074F");
                    patternNeedsValidating = PatternValidity.Valid;
                    break;
                case "Other":
                    sb.AppendLine("Cannot proceed with conversion");
                    sb.AppendLine("");
                    sb.AppendLine("Please replace 'Other' in the sletion box with a unicode block");
                    sb.AppendLine("");
                    sb.AppendLine(@"e.g. For Hebrew it would be \u0590-\u05FF");
                    MessageBox.Show(sb.ToString(), "Information");
                    break;
                default:
                    if (languageSet == "")
                    {
                        MessageBox.Show("No language set specified", "Information");
                    }
                    else
                    {
                        bool passedChecks;
                        string normaliseLanguageSetSpecification = normaliseSpecification(languageSet, out passedChecks);
                        if(passedChecks)
                        {
                            pattern = getPattern(normaliseLanguageSetSpecification);
                            patternNeedsValidating = PatternValidity.NeedsValidating;
                        }
                        else
                        {
                            patternNeedsValidating = PatternValidity.InvalidPattern;
                            sb.AppendLine("Incorrectly formatted unicode block");
                            sb.AppendLine("");
                            sb.AppendLine("Please correct and re-run conversion");
                            MessageBox.Show(sb.ToString(), "Information");
                        }
                    }
                    break;
            }
            return pattern;
        }

        private static string normaliseSpecification(string text, out bool passedChecks)
        {
            text = text.Trim().Replace(" ", "").Replace("..", "-");
            passedChecks = Regex.IsMatch(text, @"^[-\\abcdefABCDEFuU\p{N}\+]+$"); //Checks for only valid characters
            if(passedChecks)
            {
                text = Regex.Replace(text, @"(\\?[uU][+]?)([\p{L}\p{N}]{1,4})", @"\u$2"); // Standardise character format to \u####
                passedChecks = Regex.IsMatch(text, @"\\u([abcdefABCDEF\p{N}]{1,3})(?=-|\\|$)") == false; // Checks all unicode characters are 4 digits in length
            }
            return text; 
        }

        private static string getPattern(string languageBlock)
        {
            string rightSingleQuoationMark = @"\u2019";
            string directionMarkers = @"\u202A\u202C\u200E\u200F";
            string hyphens = @"\u002D\u2011\u2012\u2013\u2014";
            string terminators = @"\u2026\u2025\u002E";
            return @"(\([" + languageBlock + directionMarkers + rightSingleQuoationMark + @"]+\))*([" + languageBlock + directionMarkers + rightSingleQuoationMark +
                                   @"]+)([\s" + directionMarkers + terminators + @"{2,3}" + hyphens + @"]*([" + languageBlock + rightSingleQuoationMark + @"]+[" +
                                   directionMarkers + @"]*)+)+(\s*\([" + languageBlock + hyphens + @"]+\))*";
        }

        private static string unableToOpenFileErrorMessage(string fileName)
        {
            StringBuilder errorMessage = new StringBuilder();
            errorMessage.AppendLine("Unable to process file - check " + Path.GetFileName(fileName));
            errorMessage.AppendLine("");
            errorMessage.AppendLine("Please check that it is acorrectly formatted Microsoft Word (docx) file");
            return errorMessage.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="workerParams"></param>
        public static void ProcessDocumentNow(BackgroundWorkerParameters workerParams)
        {


            workerParams.BackgroundWorker.ReportProgress(20);

            if (MicrosoftWordProcessing.GetItemsFromFile(workerParams))
            {
                workerParams.BackgroundWorker.ReportProgress(40);
                string documentContentsAsXML = getDocumentContentsAsXML(workerParams.OriginalWordDocumentFileName, 
                                                           workerParams.IndividualFileNameInWordDocumentFile, 
                                                           unableToOpenFileErrorMessage(workerParams.IndividualFileNameInWordDocumentFile));
                workerParams.BackgroundWorker.ReportProgress(60);
                workerParams.UpdatedDocumentTextAsXML = createTransliterationsNow(documentContentsAsXML, workerParams);
                workerParams.BackgroundWorker.ReportProgress(80);
                createUpdatedWordDocumentFile(workerParams);
            }
            else
                workerParams.BackgroundWorker.ReportProgress(0);
        }


        private static List<XMLElement> trimElementList(List<XMLElement> allElementsInList)
        {
            while ((allElementsInList.Count > 0) &&
                    (allElementsInList[0].ContainsSpaceElement() || allElementsInList[0].ContainsDirectionMarker()) &&
                    (allElementsInList[0].Directionality == XMLElementDirectionality.LeftToRight))
                allElementsInList.RemoveAt(0);

            if (allElementsInList.Count > 1)
            {
                bool firstElementIsLeftToRightSpace = allElementsInList[0].ContainsSpaceElement() &&
                                                            allElementsInList[0].Directionality == XMLElementDirectionality.RightToLeft;
                bool lastElementIsLeftToRightSpace = allElementsInList[allElementsInList.Count - 1].ContainsSpaceElement() &&
                                                     allElementsInList[allElementsInList.Count - 1].Directionality == XMLElementDirectionality.LeftToRight;
                if (firstElementIsLeftToRightSpace && lastElementIsLeftToRightSpace)
                    allElementsInList.RemoveAt(allElementsInList.Count - 1);
            }
            return allElementsInList;
        }

        private static bool insertSpaceBeforeTransliteratedText(List<XMLElement> allElementsInString)
        {
            bool insertSpace = true;
            switch (allElementsInString.Count)
            {
                case 0:
                    insertSpace = true;
                    break;
                case 1:
                    insertSpace = (allElementsInString[0].ContainsSpaceElement() == false) &&
                                  (allElementsInString[0].GetContent().StartsWithASpace() == false);
                    break;
                default:
                    string lastElementText = allElementsInString[allElementsInString.Count - 1].GetContent();
                    if ((lastElementText.Length > 0) && (lastElementText[lastElementText.Length - 1] == ' '))
                        insertSpace = true;
                    else
                    if (allElementsInString[0].ContainsSpaceElement())
                        insertSpace = false;
                    else
                        insertSpace = allElementsInString[allElementsInString.Count - 1].ContainsSpaceElement() == false;
                    break;
            }
            return insertSpace;
        }

        private static bool insertSpaceAfterTransliteratedText(List<XMLElement> allElementsInString, TextItem followingTextItem)
        {
            bool insertSpace = false;
            if ((allElementsInString.Count > 0) && (followingTextItem != null))
            {
                if (Char.IsWhiteSpace(allElementsInString[allElementsInString.Count - 1].Text.FirstChar()) == false)
                {
                    if (Regex.IsMatch(followingTextItem.Text.FirstChar().ToString(), @"[\p{Pe}\p{Pf}\p{Po}]"))
                        insertSpace = false;
                    else
                    if (Char.IsWhiteSpace(followingTextItem.Text.FirstChar()))
                        insertSpace = false;
                    else
                        insertSpace = true;
                }
            }
            return insertSpace;
        }

        private static string createTransliterationsNow(string xmlText, BackgroundWorkerParameters workerParams)
        {
            TextInDocument textInDocument;
            XMLElement documentAsXml = MicrosoftWordProcessing.GetXMLElementsWhichMakeUpADocumentFromXMLString(xmlText, out textInDocument);

            xmlText = documentAsXml.ToString();

            MatchCollection matches = Regex.Matches(textInDocument.Text, workerParams.SearchPatternForTextToBeTransliterated);
            workerParams.NumberOfTransliterationsCreated = matches.Count;

            for (int index = matches.Count - 1; index > -1; index--)
            {
                if (matches[index].HasContent())
                {
                    createAndAddTransliterationToDocumentAsXml(textInDocument, matches[index], workerParams);
                }
            }
            return documentAsXml.ToString();
        }

        private static void createAndAddTransliterationToDocumentAsXml(TextInDocument textInDocument, Match match, BackgroundWorkerParameters workerParams)
        {
            List<XMLElement> elementsToInsert = new List<XMLElement>();
            List<XMLElement> allElementsInString = trimElementList(getAllXMLElementsWhichCompriseText(textInDocument, match));

            int locationOfEnd = match.Index + match.Value.Length - 1;
            TextItem textItemAtEnd = textInDocument.Index[locationOfEnd];

            bool elementIsOfTypeVanish = MicrosoftWordProcessing.IsElementOfTypeVanish(textItemAtEnd.TextElement);

            if (insertSpaceBeforeTransliteratedText(allElementsInString))
                createXMLElement(1, " ", "", "", false, elementsToInsert, elementIsOfTypeVanish);
            if (string.IsNullOrWhiteSpace(workerParams.OpeningDelimiterForTransliteratedText.Trim()) == false)
                createXMLElement(1, workerParams.OpeningDelimiterForTransliteratedText, workerParams.StyleToApplyToTransliteratedText + "Char", "", false, elementsToInsert, false);

            addTextToXMLElements(workerParams, elementsToInsert, allElementsInString);

            if (string.IsNullOrWhiteSpace(workerParams.ClosingDelimiterForTransliteratedText.Trim()) == false)
                createXMLElement(1, workerParams.ClosingDelimiterForTransliteratedText, workerParams.StyleToApplyToTransliteratedText + "Char", "", false, elementsToInsert, false);

            if (insertSpaceAfterTransliteratedText(allElementsInString, getFollowingXMLItem(textInDocument, match)))
                createXMLElement(1, " ", "", "", false, elementsToInsert, elementIsOfTypeVanish);

            MicrosoftWordProcessing.InsertListOfElementsAfterATextElement(allElementsInString[allElementsInString.Count - 1], elementsToInsert);
        }

        private static string getDocumentContentsAsXML(string wordDocumentFileName, string nameOfIndividualFileInWordDocument, string errorMessage)
        {
            return ParameterFileProcessing.GetString(wordDocumentFileName, nameOfIndividualFileInWordDocument);
        }

        private static void createUpdatedWordDocumentFile(BackgroundWorkerParameters workerParams)
        {
            ParameterFileProcessing.CreateMergedZipFile(workerParams.OriginalWordDocumentFileName, workerParams.UpdatedWordDocumentFileName, workerParams.IndividualFileNameInWordDocumentFile, ref workerParams.UpdatedDocumentTextAsXML);
            workerParams.BackgroundWorker.ReportProgress(100);
        }

        private static void createXMLElement(XMLElement anElement, string style, List<XMLElement> elementsToInsert)
        {
            XMLElement newElement = (XMLElement)anElement.Clone();
            newElement.ReplaceStyle(style);
            elementsToInsert.Add(newElement);
            newElement.ChildElements.Add(new XMLElement(99991, 1, "w:r", "", XMLElementTypes.EndElement, false));
        }

        private static void createXMLElement(int id, string text, string style, string language,
                                                 bool textIsRightToLeft, List<XMLElement> elementsToInsert,
                                                 bool isOfTypeVanish)
        {
            if (text != "")
            {
                XMLElement textElement = new XMLElement(99991, id, "w:r", "", XMLElementTypes.Content, false);
                textElement.ChildElements.Add(new XMLElement(99991, id, "w:rPr", "", XMLElementTypes.Content, false));
                if (string.IsNullOrWhiteSpace(style) == false)
                {
                    textElement.ChildElements[0].ChildElements.Add(new XMLElement(99991, id, "w:rStyle", "", XMLElementTypes.Content, true));
                    textElement.ChildElements[0].ChildElements[0].Attributes.Add(new XMLAttribute("w:val", style));
                }
                if (text != null)
                {
                    if (textIsRightToLeft)
                        textElement.ChildElements[0].ChildElements.Add(new XMLElement(99991, id, "w:rtl", "", XMLElementTypes.Content, true));
                }
                if (isOfTypeVanish)
                    textElement.ChildElements[0].ChildElements.Add(new XMLElement(99991, id, "w:vanish", "", XMLElementTypes.Content, true));
                textElement.ChildElements.Add(new XMLElement(99991, id, "w:rPr", "", XMLElementTypes.EndElement, false));
                if (text != null)
                {
                    textElement.ChildElements.Add(new XMLElement(9991, id, "w:t", text, XMLElementTypes.Content, false));
                    textElement.ChildElements[textElement.ChildElements.Count - 1].Attributes.Add(new XMLAttribute("xml:space", @"preserve"));
                    textElement.ChildElements.Add(new XMLElement(99991, id, "w:t", "", XMLElementTypes.EndElement, false));
                }
                textElement.ChildElements.Add(new XMLElement(99991, id, "w:r", "", XMLElementTypes.EndElement, false));
                elementsToInsert.Add(textElement);
            }
        }

        private static TextItem getFollowingXMLItem(TextInDocument textInDocument, Match match)
        {
            int prevIndex = match.Index + match.Length - 1;
            int index = match.Index + match.Length;
            TextItem prevTextItem = textInDocument.Index[index - 1];
            TextItem followingTextItem = textInDocument.Index[index];

            while (prevTextItem == followingTextItem)
            {
                index++;
                followingTextItem = textInDocument.Index[index];
            }

            return followingTextItem;
        }

        private static List<XMLElement> getAllXMLElementsWhichCompriseText(TextInDocument textInDocument, Match match)
        {
            TextItem prevTextItem = textInDocument.Index[match.Index - 1];
            TextItem followingTextItem = textInDocument.Index[match.Index + 1];
            TextItem followingPlusOneItem = textInDocument.Index[match.Index + 2];

            List<XMLElement> elements = new List<XMLElement>();
            int index = match.Index;
            TextItem textItem;
            while (index < match.Index + match.Length)
            {
                textItem = textInDocument.Index[index];
                elements.Add((XMLElement)textItem.TextElement.Parent.Clone());
                elements[elements.Count - 1].Parent = textItem.TextElement.Parent;
                index += textItem.Text.Length;
            }
            return elements;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static string GetXMLElementText(XMLElement element)
        {
            string text = "";
            if (element.Type == XMLElementTypes.Content)
                text = element.Text;
            else
            {
                foreach (XMLElement anElement in element.ChildElements)
                {
                    text += GetXMLElementText(anElement);
                }
            }
            return text;
        }

        private static void trimElements(List<XMLElement> elements)
        {
            while (elements.Count > 0)
            {
                if (GetXMLElementText(elements[0]).Trim().TrimDirectionMarkers() == "")
                    elements.RemoveAt(0);
                else
                    break;
            }
            while (elements.Count > 0)
            {
                if (GetXMLElementText(elements[elements.Count - 1]).Trim().TrimDirectionMarkers() == "")
                    elements.RemoveAt(elements.Count - 1);
                else
                    break;
            }
        }

        private enum TrimTypes { Begining, End, Both }
        private static XMLElement trimTextInXMLElement(XMLElement element, TrimTypes trimType)
        {
            if (element.Type == XMLElementTypes.Content)
            {
                switch (trimType)
                {
                    case TrimTypes.Begining:
                        element.Text = element.Text.TrimStart().TrimDirectionMarkers();
                        break;
                    case TrimTypes.End:
                        element.Text = element.Text.TrimEnd().TrimDirectionMarkers();
                        break;
                    case TrimTypes.Both:
                        element.Text = element.Text.Trim().TrimDirectionMarkers();
                        break;
                }
            }
            else
                foreach (XMLElement childElement in element.ChildElements)
                {
                    trimTextInXMLElement(childElement, trimType);
                }
            return element;
        }

        private static void addTextToXMLElements(BackgroundWorkerParameters workerParams, List<XMLElement> elementsToInsert, List<XMLElement> textAsACollectionOfElements)
        {
            trimElements(textAsACollectionOfElements);
            if (textAsACollectionOfElements.Count > 0)
            {
                switch (textAsACollectionOfElements.Count)
                {
                    case 1:
                        trimTextInXMLElement(textAsACollectionOfElements[textAsACollectionOfElements.Count - 1], TrimTypes.Both);
                        break;
                    default:
                        trimTextInXMLElement(textAsACollectionOfElements[textAsACollectionOfElements.Count - 1], TrimTypes.End);
                        break;
                }
                for (int index = 0; index < textAsACollectionOfElements.Count; index++)
                {
                    XMLElement element = textAsACollectionOfElements[index];
                    createXMLElement(element, workerParams.StyleToApplyToTransliteratedText + "Char", elementsToInsert);
                }
            }
        }

        /* see: https://stackoverflow.com/questions/22339260/how-do-i-add-files-to-an-existing-zip-archive */
    }

    enum TextDirections { LeftToRight, RightToLeft }
    class TextComponent
    {
        public string Text;
        public TextDirections TextDirection;

        public TextComponent()
        {
            Text = "";
            TextDirection = TextDirections.LeftToRight;
        }
    }

}

