﻿using System.Windows.Forms;

namespace mm.BackgroundWorkerNameSpace
{
    /// <summary>
    /// <para>The class <c>BackgroundWorkerParameters</c> contains the necessary parameters to process a file in the background</para>
    /// <para>It also links the background worker thread to the user interface thread in order to update the progress bar</para>
    /// </summary>
    public class BackgroundWorkerParameters
    {
        /// <summary>
        /// Returns a pointer back to the UIU thread
        /// </summary>
        public System.ComponentModel.BackgroundWorker BackgroundWorker;
        /// <summary>
        /// Specifies closing delimeter to be added to the inserted transliteration text
        /// </summary>
        public string ClosingDelimiterForTransliteratedText;
        /// <summary>
        /// Specifies the name of the xml file, within the docx Word Document file, which needs to be processed
        /// </summary>
        public string IndividualFileNameInWordDocumentFile;
        /// <summary>
        /// Returns the number of transliterations added
        /// </summary>
        public int NumberOfTransliterationsCreated;
        /// <summary>
        /// Returns the original text as an xml string
        /// </summary>
        public string OriginalDocumentTextAsXML;
        /// <summary>
        /// Specifies the name of the docx Word Document file being processed
        /// </summary>
        public string OriginalWordDocumentFileName;
        /// <summary>
        /// Specifies the opening delimeter to be added to the inserted transliteration text
        /// </summary>
        public string OpeningDelimiterForTransliteratedText;
        /// <summary>
        /// Pointer to the progress bar
        /// </summary>
        public ToolStripProgressBar Progressbar;
        /// <summary>
        /// The name of the file docx file to be created containg the completed document  
        /// </summary>
        public SaveFileDialog SaveFileDlg;
        /// <summary>
        /// A Regular Expresion to be used when searching for strings to be transliterated
        /// </summary>
        public string SearchPatternForTextToBeTransliterated;
        /// <summary>
        /// The name of Microsoft Word style to be applied to the transliterated text
        /// </summary>
        public string StyleToApplyToTransliteratedText;
        /// <summary>
        /// Contains the processed text as an xml string
        /// </summary>
        public string UpdatedDocumentTextAsXML;
        /// <summary>
        /// Specifies the name of the docx Word Document to which the updated text should be added
        /// </summary>
        public string UpdatedWordDocumentFileName;

        /// <summary>
        /// <c>BackgroundWorkerParameters</c> Initialises the backgrounderworker parameter specification
        /// </summary>
        /// <param name="searchPattern"></param>
        /// <param name="styleToApply"></param>
        /// <param name="openingDelimiter"></param>
        /// <param name="closingDelimter"></param>
        /// <param name="progressbar"></param>
        /// <param name="initialFileName"></param>
        /// <param name="updatedFileName"></param>
        /// <param name="individualFileNameInWordDocumentFile"></param>
        /// <param name="backgroundWorker"></param>
        public BackgroundWorkerParameters(string searchPattern, string styleToApply, string openingDelimiter, string closingDelimter, 
                                            ToolStripProgressBar progressbar, string initialFileName, string updatedFileName, string individualFileNameInWordDocumentFile,
                                            System.ComponentModel.BackgroundWorker backgroundWorker)
        {
            SearchPatternForTextToBeTransliterated = searchPattern;
            StyleToApplyToTransliteratedText = styleToApply;
            OpeningDelimiterForTransliteratedText = openingDelimiter.Trim();
            ClosingDelimiterForTransliteratedText = closingDelimter.Trim(); 
            NumberOfTransliterationsCreated = 0;
            Progressbar = progressbar; 
            OriginalWordDocumentFileName = initialFileName;
            UpdatedWordDocumentFileName = updatedFileName;
            IndividualFileNameInWordDocumentFile = individualFileNameInWordDocumentFile;
            BackgroundWorker = backgroundWorker;
            OriginalDocumentTextAsXML = "";
            UpdatedDocumentTextAsXML = ""; 
        }
    }
}
