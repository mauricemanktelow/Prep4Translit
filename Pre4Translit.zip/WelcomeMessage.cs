﻿using System.Windows.Forms;
using System.Text;

namespace Prep4Translit
{
    public partial class FormMain : Form
    {

        private void WelcomeMessageInitialise()
        {
            PopulateWelcomeMessage();
            if (Properties.Settings.Default.HideWelcomeMessage)
            {
                tabControlMain.SelectedIndex = 1;
                tabControlMain.TabPages[1].Focus();
            }
            else
            {
                tabControlMain.SelectedIndex = 0;
                tabControlMain.TabPages[0].Focus();
            }
        }

        private void PopulateWelcomeMessage()
        {
            StringBuilder welcomeText = new StringBuilder();
            welcomeText.Append(@"<html>");
            welcomeText.Append(@"<head>");
            welcomeText.Append(@"<title>Keyboard Mapping</title>");
            welcomeText.Append(@"<style></style>");
            welcomeText.Append(@"</head>");
            welcomeText.Append(@"<body>");
            welcomeText.Append(@"<font face=""Verdana"" size=""2"">");
            welcomeText.Append(@"<font size=""4"" color=""0000FF""><strong>Welcome</strong></font>");
            welcomeText.Append(@"<p>This program has been written to insert transliterated text immediately following any Greek or Hebrew text in an original Microsoft Word (docx) file.</p>");
            welcomeText.Append(@"<p>You will be invited to specify a style which should have previously been created in the Microsoft Word document and which will be applied to the transliterated text</p>");
            welcomeText.Append(@"<p>You will be invited to choose delimiters to surround the transliterated text that will help checking but can be deleted within Word at a later stage</p>");
            welcomeText.Append(@"<p>These can subsequently be removed within Microsoft Word</p>");
            welcomeText.Append(@" <p></p>");
            welcomeText.Append(@"<p>Comments, feedback, requests for additional features, bug reports etc are welcome. Please send them to <a href=mailto:""mailto:support@mauricem.net"">support@mauricem.net</a></p>");
            welcomeText.Append(@"</font>");
            welcomeText.Append(@"</body>");
            webBrowserWelcomeMessage.DocumentText = welcomeText.ToString();
        }
    }
}
