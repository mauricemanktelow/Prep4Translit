﻿using System;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;
using mm.Utilities;
using System.Drawing;

namespace mm.Extensions
{
    public static class FileExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileInfo"></param>
        /// <param name="name"></param>
        public static void RenameTo(this FileInfo fileInfo, string name)
        {
            if (fileInfo == null)
            {
                throw new ArgumentNullException("fileInfo", "File info to rename cannot be null");
            }
            if (string.IsNullOrEmpty(name.Trim()))
            {
                throw new ArgumentException("New name cannot be null or blank", name);
            }
            string newName = Path.Combine(fileInfo.DirectoryName, name);
            if (File.Exists(newName))
                throw new ArgumentException("Cannot rename file - a file with this name already exists", name);
            else
                fileInfo.MoveTo(newName);
            return;
        }
    }
}
