using System;
using System.Globalization;


namespace mm.ConstantsSpecifications
{
    /// <summary>
    /// 
    /// </summary>
    public class Constants
    {
        public const char CarriageReturn = (char)13;
        public const char NewLine = (char)10;
        public const char TabCharacter = (char)9;
        public const char BackSlash = (char)220;
        public const string AmbigousHyphenHex = "002D";
        public const string BulletDotHex = "2022";
        public const string BulletHyphenHex = "2043";
        public const string BulletTwoDotsHex = "2022";
        public const string BulletThreeDotsHex = "2026";
        public const string EnDashHex = "2013";
        public const string EmDashHex = "2014";
        public const Char AmbiguousHyphenCharacter = (Char)45;
        public const Char EnDashUnicodeCharacter = (Char)8211;
        public const Char EmDashUnicodeCharacter = (Char)8212;
        public const string QuotationDashHex = "2015";
        public const string UnAmbiguousHyhphen = "2010";
        public const string MinusSignHex = "2212";
        public const string EOLHyphen = "?-?";
        public const char SmartOpeningSingleQuotationMark = '�';
        public const char SmartOpeningDoubleQuotationMark = '�';
        public const char SmartClosingSingleQuotationMark = '�';
        public const char SmartClosingDoubleQuotationMark = '�';
        public const char SingleQuotationMark = '\'';
        public const char DoubleQuotationMark = '"';
        public const char QuestionMark = '?';
        public const char ExclamationMark = '!';
        public const char Period = '.';
        public const char Space = ' ';
        public static string LeftArrow_UnicodeValue = ((char)8592).ToString();
        public static string UpArrow_UnicodeValue = ((char)8593).ToString();
        public static string RightArrow_UnicodeValue = ((char)8594).ToString();
        public static string DownArrow_UnicodeValue = ((char)8595).ToString();

        public static string BulletDotUnicodeValue = Char.ConvertFromUtf32(Int32.Parse(BulletDotHex, NumberStyles.HexNumber));
        public static string BulletHyphenUnicodeValue = Char.ConvertFromUtf32(Int32.Parse(BulletHyphenHex, NumberStyles.HexNumber));
        public static string MinusSignUnicodeValue = Char.ConvertFromUtf32(Int32.Parse(MinusSignHex, NumberStyles.HexNumber));
        public static string QuotationDashUnicodeValue = Char.ConvertFromUtf32(Int32.Parse(QuotationDashHex, NumberStyles.HexNumber));
        public static string UnAmbiguousHyphenUnicodeValue = Char.ConvertFromUtf32(Int32.Parse(UnAmbiguousHyhphen, NumberStyles.HexNumber));
        public static string EOLHyphenUnicodeValue = EOLHyphen;
        public static string AmbiguousHyphenUnicodeValue = Char.ConvertFromUtf32(Int32.Parse(AmbigousHyphenHex, NumberStyles.HexNumber));
        public static string EmDashUnicodeValue = Char.ConvertFromUtf32(Int32.Parse(EmDashHex, NumberStyles.HexNumber));
        public static string EnDashUnicodeValue = Char.ConvertFromUtf32(Int32.Parse(EnDashHex, NumberStyles.HexNumber));



        public static string AllHyphensAndDashes = AmbiguousHyphenUnicodeValue +
                                          BulletDotUnicodeValue +
                                          BulletHyphenUnicodeValue +
                                          EmDashUnicodeValue +
                                          EnDashUnicodeValue +
                                          MinusSignUnicodeValue +
                                          QuotationDashUnicodeValue +
                                          //EOLHyphenClass.Unicode +             
                                          UnAmbiguousHyphenUnicodeValue;

        public static string AllHyphensExceptEnDash = Constants.AllHyphensAndDashes.Replace(Constants.EnDashUnicodeValue, "");
        public static string AllHyphensExceptEmDash = Constants.AllHyphensAndDashes.Replace(Constants.EmDashUnicodeValue, "");
        public static string AllHyphensExceptEmDashAndUnambiguousHyphen = Constants.AllHyphensAndDashes.Replace(Constants.EmDashUnicodeValue, "").Replace(Constants.UnAmbiguousHyphenUnicodeValue,"");


        public const char SpaceCharacter = (char)32;
        public const char NonBreakingSpaceCharacter = (char)160;
        public const char ThinSpaceCharacter = (char)8201;
        public const char HairSpaceCharacter = (char)8202;
        public const char ZeroWidthSpaceCharacter = (char)8203;
        public const char EnSpaceCharacter = (char)8194;
        public const char EmSpaceCharacter = (char)8195;

        public const char OghamSpaceCharacter = (char)5760;
        public const char EnQuadSpaceCharacter = (char)8193;
        public const char ThreePerEmSpaceCharacter = (char)8196;
        public const char FourPerEmSpaceCharacter = (char)8197;
        public const char SixPerEmSpaceCharacter = (char)8198;
        public const char FigureSpaceCharacter = (char)8199;
        public const char PunctuationSpaceCharacter = (char)8200;
        public const char NarrowNonBreakSpaceCharacter = (char)8239;
        public const char MediumMathematicalSpaceCharacter = (char)8287;
        public const char IdeographicalSpaceCharacter = (char)12288;


        public static string AllSpaces = SpaceCharacter.ToString() + 
                                         ThinSpaceCharacter.ToString() + 
                                         HairSpaceCharacter.ToString() +
                                         NonBreakingSpaceCharacter.ToString() + 
                                         EnSpaceCharacter.ToString() + 
                                         EmSpaceCharacter.ToString() +
                                         OghamSpaceCharacter.ToString() +
                                         EnQuadSpaceCharacter.ToString() +
                                         ThreePerEmSpaceCharacter.ToString() +
                                         FourPerEmSpaceCharacter.ToString() +
                                         SixPerEmSpaceCharacter.ToString() +
                                         FigureSpaceCharacter.ToString() +
                                         PunctuationSpaceCharacter.ToString() +
                                         NarrowNonBreakSpaceCharacter.ToString() +
                                         MediumMathematicalSpaceCharacter.ToString() +
                                         IdeographicalSpaceCharacter.ToString();




        public const int Backspace_KeyValue = 8;
        public const int BreakKey_KeyValue = 19;
        public const int CapsLock_KeyValue = 20;
        public const int Del_KeyValue = 46;
        public const int DownArrow_KeyValue = 40;
        public const int End_KeyValue = 35;
        public const int Enter_KeyValue = 13;
        public const int Esc_KeyValue = 27;
        public const int ForwardSlash_KeyValue = 220;
        public const int Home_KeyValue = 36;
        public const int Insert_KeyValue = 45;
        public const int LeftArrow_KeyValue = 37;
        public const int Menu_KeyValue = 93;
        public const int NewLine_KeyValue = 10;
        public const int NumLock_KeyValue = 144;
        public const int PageDown_KeyValue = 34;
        public const int PageUp_KeyValue = 33;
        public const int RightArrow_KeyValue = 39;
        public const int Space_KeyValue = 32;
        public const int TabKey_KeyValue = 0;
        public const int UpArrow_KeyValue = 38;
        public const int Windows_KeyValue = 91;

        public const int LetterAKeyPressValue = 65;
        public const int LetterBKeyPressValue = 66;
        public const int LetterCKeyPressValue = 67;
        public const int LetterDKeyPressValue = 68;
        public const int LetterEKeyPressValue = 69;
        public const int LetterFKeyPressValue = 70;
        public const int LetterGKeyPressValue = 71;
        public const int LetterHKeyPressValue = 72;
        public const int LetterIKeyPressValue = 73;
        public const int LetterJKeyPressValue = 74;
        public const int LetterKKeyPressValue = 75;
        public const int LetterLKeyPressValue = 76;
        public const int LetterMKeyPressValue = 77;
        public const int LetterNKeyPressValue = 78;
        public const int LetterOKeyPressValue = 79;
        public const int LetterPKeyPressValue = 80;
        public const int LetterQKeyPressValue = 81;
        public const int LetterRKeyPressValue = 82;
        public const int LetterSKeyPressValue = 83;
        public const int LettertKeyPressValue = 84;
        public const int LetteruKeyPressValue = 85;
        public const int LetterVKeyPressValue = 86;
        public const int LetterwKeyPressValue = 87;
        public const int LetterXKeyPressValue = 88;
        public const int LetterYKeyPressValue = 89;
        public const int LetterZKeyPressValue = 90;

        public const int NumberZero = 48;
        public const int NumberOne = 49;
        public const int NumberTwo = 50;
        public const int NumberThree = 51;
        public const int NumberFour = 52;
        public const int NumberFive = 53;
        public const int NumberSix = 54;
        public const int NumberSeven = 55;
        public const int NumberEight = 56;
        public const int NumberNine = 59;

        public const int Ascii_Space = 32;
        public const int Ascii_CarraigeReturn = 13;
        public const int Ascii_LineFeed = 10;
        public static string HebrewPunctuationPaseq = ((char)1472).ToString();
        public static string ArabicDigitZero = ((char)1632).ToString();
        public static string HebrewSpaceSubstituteCharacter = ArabicDigitZero;


        public static bool IsASpace(char character)
        {
            return (character == SpaceCharacter) ||
                   (character == NonBreakingSpaceCharacter) ||
                   (character == ThinSpaceCharacter) ||
                   (character == HairSpaceCharacter) ||
                   (character == ZeroWidthSpaceCharacter) ||
                   (character == EnSpaceCharacter) ||
                   (character == EmSpaceCharacter);
        }

        public static bool IsATab(char character)
        {
            return character == TabCharacter;
        }
    }
}