using System;
using System.Windows.Forms;
using System.Threading;

namespace mm.Utilities
{
    /// <summary>
    /// Class <c>Beep</c> sounds a beep on the computer loudspeeaker.
    /// <para>It is normally used to provide a warning of an incorrect action being attempted</para>
    /// </summary>
    public static class Beep
    {
        /// <summary>
        /// Sound a short beep 
        /// </summary>
        public static void SingleBeep()
        {
            SoundASingleBeep(false, "", 350, 250);
        }

        /// <summary>
        /// Sound a short beep or display a message when in silent mode
        /// <param name="silentMode"> provides an option to show a message rather than make a sound</param>
        /// <param name="message"> is the alternative message displayed to playing a sound</param>
        /// </summary>
        public static void SingleBeep(bool silentMode, string message)
        {
            SoundASingleBeep(silentMode, message, 350, 250);
        }

        /// <summary>
        /// Sound a short beep or display a message when in silent mode
        /// </summary>
        /// <param name="silentMode"> provides an option to show a message rather than make a sound</param>
        /// <param name="message"> is the alternative message displayed to playing a sound</param>
        /// <param name="frequency">Frequency of beep sound</param>
        /// <param name="duration">Duration of beep sound</param>
        public static void SoundASingleBeep(bool silentMode, string message, int frequency, int duration)
        {
            if (silentMode)
                MessageBox.Show(message, "");
            else
                Console.Beep(frequency, duration);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="no">Number of times beep to be sounded</param>
        public static void SoundRepeatedBeepsNow(int no)
        {
            switch (no)
            {
                case 0:
                    break;
                case 1:
                    SoundASingleBeep(false, "", 500, 250);
                    break;
                default:
                    for (int count = 1; count < no; count++)
                    {
                        Thread.Sleep(150);
                        SoundASingleBeep(false, "", 500, 250);
                    }
                    break;
            }
        }
    }

}