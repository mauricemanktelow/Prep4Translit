﻿using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Xml.Serialization;
using System.IO.Compression;
using System.Windows.Media.Imaging;

namespace mm.Utilities
{

    /// <summary>
    /// 
    /// </summary>
    public class ZipFileResultsClass
    {
        /// <summary>
        /// 
        /// </summary>
        public ParameterFileProcessing.ZipFileResults Result;

        /// <summary>
        /// 
        /// </summary>
        public String ErrMessage;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="result"></param>
        /// <param name="errMessage"></param>
        public ZipFileResultsClass(ParameterFileProcessing.ZipFileResults result)
        {
            Result = result;
        }

        /// <summary>
        /// 
        /// </summary>
        public ZipFileResultsClass()
        {
            Result = ParameterFileProcessing.ZipFileResults.NotKnownResult;
            ErrMessage = "";
        }
    }

    /// <summary>
    /// Class <c>ParameterFileProcessing</c> provides a set of methods for processing Zip files
    /// <para>These were originally designed for processing files with an extension of .datx but can be used for files with other extensions</para>
    /// </summary>
    public class ParameterFileProcessing
    {
        public enum ZipFileResults { NotKnownResult, Success, ZipFileNotFound, ZipFileErrorOpening, ContentsFileNotFound, ErrorExtractingFileContents };
        public ZipFileResultsClass ZipFileResult;


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceZipFileName"></param>
        /// <param name="newZipFileName"></param>
        /// <param name="nameOfIndividualFileToBeInserted"></param>
        /// <param name="insertedFileContent"></param>
        public static void CreateMergedZipFile(string sourceZipFileName, string newZipFileName, string nameOfIndividualFileToBeInserted, ref string insertedFileContent)
        {
            if (File.Exists(newZipFileName))
            {
                try
                {
                    File.Delete(newZipFileName);
                }
                catch (Exception err)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine(err.Message);
                    sb.AppendLine("");
                    sb.AppendLine("Conversion cancelled - please close file and run conversion again");
                    MessageBox.Show(sb.ToString(), "Information");
                    return;
                }
            }
            using (ZipArchive source = ZipFile.OpenRead(sourceZipFileName))
            using (ZipArchive target = ZipFile.Open(newZipFileName, ZipArchiveMode.Update))
            {
                ZipArchiveEntry targetEntry;
                foreach (var entry in source.Entries)
                {

                    targetEntry = target.GetEntry(entry.FullName);
                    targetEntry = target.CreateEntry(entry.FullName);
                    if (entry.FullName == nameOfIndividualFileToBeInserted)
                    {
                        using (StreamWriter writer = new StreamWriter(targetEntry.Open()))
                        {
                            writer.Write(insertedFileContent);
                        }
                    }
                    else
                    {
                        using (var sourceStream = entry.Open())
                        using (var targetStream = targetEntry.Open())
                        {
                            sourceStream.CopyTo(targetStream);
                        }
                    }
                }
            }
        }

        private static bool GetContentFromFile(string zipFileName, string fileName, out string contentExtractedToFile, ZipFileResultsClass resultArgs)
        {
            fileName = fileName.ToLower();
            bool contentsExtracted = false;
            contentExtractedToFile = GetTempFileName();
            if (File.Exists(zipFileName))
            {
                using (ZipArchive archive = ZipFile.OpenRead(zipFileName))
                {
                    foreach (ZipArchiveEntry entry in archive.Entries)
                    {
                        if (entry.FullName.ToLower() == fileName)
                        {
                            entry.ExtractToFile(contentExtractedToFile);
                            contentsExtracted = true;
                            break;
                        }
                    }
                }
                if (!contentsExtracted)
                {
                    resultArgs.Result = ZipFileResults.ContentsFileNotFound;
                }
            }
            else
            {
                resultArgs.Result = ZipFileResults.ZipFileNotFound;
            }
            return contentsExtracted;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="fileName"></param>
        public static void SerialiseObjectAndSaveToFile(object sender, string fileName)
        {
            try
            {
                Type type = sender.GetType();
                XmlSerializer serializer = new XmlSerializer(sender.GetType());
                using (StreamWriter writer = new StreamWriter(fileName, false, Encoding.UTF8))
                {
                    serializer.Serialize(writer, sender);
                    writer.Flush();
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("Error trying to save params file: " + err.Message, "Error");
                Environment.Exit(0);
            }
        }

        /// <summary>
        /// Save / Overwrite a string to a file within a zip file
        /// </summary>
        /// <param name="textToBeAdded"></param>
        /// <param name="zipFileName"></param>
        /// <param name="contentFileName"></param>
        public static void AddTextToZipFile(String textToBeAdded, String zipFileName, String contentFileName)
        {
            try
            {
                string tempFolder = Environment.ExpandEnvironmentVariables("%temp%");
                string fullContentFileName = tempFolder + @"\" + contentFileName.Replace("/", "\\");
                if (Directory.Exists(Path.GetDirectoryName(fullContentFileName)) == false)
                    Directory.CreateDirectory(Path.GetDirectoryName(fullContentFileName));
                FileInfo fi = new FileInfo(fullContentFileName);
                FileUtilities.SetFileReadWriteAttributes(fullContentFileName, false);
                using (TextWriter writer = new StreamWriter(fullContentFileName, false, Encoding.UTF8))
                {
                    writer.Write(textToBeAdded);
                }
                // Add file to zipfile
                if (!File.Exists(zipFileName))
                {
                    //     File.Create(zipFileName);
                }
                // Remove existing file if it exists in the zip file
                using (ZipArchive archive = ZipFile.Open(zipFileName, ZipArchiveMode.Update))
                {
                    int index = archive.Entries.Count - 1;
                    while (index > -1)
                    {
                        ZipArchiveEntry entry = archive.Entries[index];
                        if (entry.FullName.ToLower() == contentFileName.ToLower())
                            entry.Delete();
                        index--;
                    }
                    archive.CreateEntryFromFile(fullContentFileName, contentFileName);
                }
                fi.Delete();
            }
            catch (Exception err)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Error encountered when trying to save file ");
                sb.AppendLine("File: " + contentFileName);
                sb.AppendLine("");
                sb.AppendLine("Error message: " + err.Message);
                MessageBox.Show(sb.ToString());
            }
        }

        /// <summary>
        /// Check datx file exists
        /// </summary>
        /// <returns></returns>
        public static bool CheckDatxFileExists(string zipFileName)
        {
            bool result = File.Exists(zipFileName);
            if (!result)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Missing " + Path.GetExtension(zipFileName).Replace(".","") + " file");
                sb.AppendLine("");
                sb.AppendLine("Please put this in the same folder as the exe file and re-run the program");
                sb.AppendLine("");
                sb.AppendLine("The program will now close");
                sb.AppendLine("");
                sb.AppendLine("Thank you");
                MessageBox.Show(sb.ToString(), "Information");
            }
            return result;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="zipFileName"></param>
        /// <param name="fileName"></param>
        /// <param name="resultArgs"></param>
        /// <returns></returns>
        private static object InitialiseXmlObjectFromFile(object sender, string zipFileName, string fileName, ZipFileResultsClass resultArgs)
        {
            resultArgs.ErrMessage = "Hello";
            string contentFileName = "";
            try
            {
                if (GetContentFromFile(zipFileName, fileName, out contentFileName, resultArgs))
                {
                    XmlSerializer serializer = new XmlSerializer(sender.GetType());
                    using (StreamReader reader = new StreamReader(contentFileName))
                    {
                        sender = serializer.Deserialize(reader);
                    }
                }
            }
            catch (Exception err)
            {
                resultArgs.Result = ZipFileResults.ErrorExtractingFileContents;
                resultArgs.ErrMessage = err.Message;
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Error trying to read params file: ");
                sb.AppendLine("    " + fileName);
                sb.AppendLine("");
                sb.AppendLine(err.Message);
                MessageBox.Show(sb.ToString(), "Error");
            }
            return sender;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="datxFileName"></param>
        /// <param name="individualFileName"></param>
        /// <returns></returns>
        public static string GetString(string datxFileName, string individualFileName)
        {
            string result = "";
            result = ParameterFileProcessing.GetFileContents(result, datxFileName, individualFileName) as String;
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="datxFileName"></param>
        /// <param name="individualFileName"></param>
        /// <returns></returns>
        public static List<string> GetStringList(string datxFileName, string individualFileName)
        {
            List<string> result = new List<string>();
            result = new List<string>();
            string listAsAString = "";
            listAsAString = (string)ParameterFileProcessing.GetFileContents(listAsAString, datxFileName, individualFileName);
            if (string.IsNullOrEmpty(listAsAString) == false)
            {
                string[] lines = listAsAString.Split('\n');
                foreach (string aLine in lines)
                {
                    string trimedLine = aLine.Trim();
                    if (String.IsNullOrEmpty(trimedLine) == false)
                        result.Add(trimedLine);
                }
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="zipFileName"></param>
        /// <param name="fileName"></param>
        /// <param name="resultArgs"></param>
        /// <returns></returns>
        private static object InitialiseTextObjectFromFile(object sender, string zipFileName, string fileName, ZipFileResultsClass resultArgs)
        {
            resultArgs.ErrMessage = "Hello";
            string contentFileName = "";
            if (GetContentFromFile(zipFileName, fileName, out contentFileName, resultArgs))
            {
                try
                {
                    using (TextReader reader = new StreamReader(contentFileName))
                    {
                        if ((sender is IList) || (sender is SortedList))
                        {
                            string line;
                            SortedList tempList = new SortedList();
                            while ((line = reader.ReadLine()) != null)
                            {
                                tempList.Add(line, "");
                            }
                            sender = (SortedList)tempList.Clone();
                        }
                        else
                            if (sender is String)
                            sender = reader.ReadToEnd();
                    }
                }
                catch (Exception err)
                {
                    resultArgs.Result = ZipFileResults.ErrorExtractingFileContents;
                    resultArgs.ErrMessage = err.Message;
                    MessageBox.Show("Error trying to read params file: " + err.Message, "Error");
                }
                finally
                {
                    if (File.Exists(contentFileName))
                        File.Delete(contentFileName);
                }
            }
            return sender;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="zipFileName"></param>
        /// <param name="individualFileName"></param>
        /// <param name="resultArgs"></param>
        /// <returns></returns>
        private static object GetFileContentsAsString(object sender, string zipFileName, string individualFileName, ZipFileResultsClass resultArgs)
        {
            string tempFileName = "";

            if (GetContentFromFile(zipFileName, individualFileName, out tempFileName, resultArgs))
            {
                try
                {
                    using (TextReader reader = new StreamReader(tempFileName))
                    {
                        sender = reader.ReadToEnd();
                    }
                }
                catch (Exception err)
                {
                    resultArgs.Result = ZipFileResults.ErrorExtractingFileContents;
                    resultArgs.ErrMessage = err.Message;
                    MessageBox.Show("Error trying to read params file: " + err.Message, "Error");
                }
            }
            if (File.Exists(tempFileName))
                File.Delete(tempFileName);
            return sender;
        }

        private static string GetTempFileName()
        {
            string tempFileName = Path.GetTempFileName();
            if (File.Exists(tempFileName))
                File.Delete(tempFileName);
            return tempFileName;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="resultArgs"></param>
        /// <returns></returns>
        private static BitmapImage GetFileContentsAsBitmap(object sender, ZipFileResultsClass resultArgs)
        {
            BitmapImage result = null;
            string tempFileName = GetTempFileName();
            try
            {
                MemoryStream memStream = new MemoryStream();
                using (FileStream fileStream = new FileStream(tempFileName, FileMode.Open, FileAccess.Read))
                {
                    memStream.SetLength(fileStream.Length);
                    fileStream.Read(memStream.GetBuffer(), 0, (int)fileStream.Length);
                }
                result = new BitmapImage();
                result.BeginInit();
                result.StreamSource = memStream;
                result.EndInit();
            }
            catch (Exception err)
            {
                resultArgs.Result = ZipFileResults.ErrorExtractingFileContents;
                resultArgs.ErrMessage = err.Message;
                MessageBox.Show("Error trying to read params file: " + err.Message, "Error");
            }
            finally
            {
                if (File.Exists(tempFileName))
                    File.Delete(tempFileName);
            }
            return result;
        }

        /// <summary>
        /// Check file exists with the zip file
        /// </summary>
        /// <param name="zipFileName"></param>
        /// <param name="contentFileName"></param>
        /// <returns></returns>
        public static bool CheckContentFileExists(string zipFileName, string contentFileName)
        {
            bool result = false;
            if (CheckDatxFileExists(zipFileName))
            {
                try
                {
                    using (ZipArchive archive = ZipFile.Open(zipFileName, ZipArchiveMode.Read))
                    {
                        for (int index = 0; index < archive.Entries.Count; index++)
                        {
                            ZipArchiveEntry entry = archive.Entries[index];
                            if (entry.FullName.ToLower() == contentFileName.ToLower())
                            {
                                result = true;
                                break;
                            }
                        }
                    }
                }
                catch
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("Cannot open file");
                    sb.AppendLine("");
                    sb.AppendLine("     " + Path.GetFileName(zipFileName));
                    sb.AppendLine("");
                    sb.AppendLine("It is either not the correct file type or is corrupt");
                    MessageBox.Show(sb.ToString(), "Error");
                    return false;
                }
            }
            if (!result)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine(contentFileName + " is missing from the " + Path.GetExtension(zipFileName).Replace(".", "") + " file");
                sb.AppendLine("");
                sb.AppendLine("Please get an update datx file and re-run the program");
                sb.AppendLine("");
                sb.AppendLine("The program will now close");
                sb.AppendLine("");
                sb.AppendLine("Thank you");
                MessageBox.Show(sb.ToString(), "Information");
            }
            return result;
        }

        private static bool CheckIndividualFileExistsWithinAZipFile(string zipFileName, string contentFileName)
        {
            bool result = false;
            StringBuilder sb = new StringBuilder();
            if (ParameterFileProcessing.CheckDatxFileExists(zipFileName) == false)
            {
                MessageBox.Show("Cannot find file " + Path.GetFileName(zipFileName), "Information");
            }
            else
            {
                result = ParameterFileProcessing.CheckContentFileExists(zipFileName, contentFileName);
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="zipFileName"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static object GetFileContents(object sender, string zipFileName, string fileName)
        {
            if (CheckIndividualFileExistsWithinAZipFile(zipFileName, fileName))
            {
                ZipFileResultsClass resultArgs = new ZipFileResultsClass(ZipFileResults.Success);
                if (sender is String)
                    sender = GetFileContentsAsString(sender, zipFileName, fileName, resultArgs);
                else
                if (sender is IList)
                {
                    if (SenderIsListOfStrings(sender))
                    {
                        sender = GetStringList(zipFileName, fileName);
                    }
                    else
                    if (sender.GetType().IsGenericType)
                    {
                        sender = InitialiseXmlObjectFromFile(sender, zipFileName, fileName, resultArgs);
                    }
                }
                else
                    if (sender is SortedList)
                {
                    sender = InitialiseTextObjectFromFile(sender, zipFileName, fileName, resultArgs);
                }
                else
                    if (sender is BitmapImage)
                    sender = GetFileContentsAsBitmap(sender, resultArgs);
                else
                    if (sender is Object)
                {
                    sender = InitialiseXmlObjectFromFile(sender, zipFileName, fileName, resultArgs);
                }
            }
            return sender;
        }

        private static bool SenderIsListOfStrings(object sender)
        {
            return (sender as List<string>) != null;
        }

    }
}