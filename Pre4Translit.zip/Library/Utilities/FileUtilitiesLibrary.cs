﻿using System;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Net;

namespace mm.Utilities
{
    /// <summary>
    /// 
    /// </summary>
    public static class FileUtilities
    {
        /// <summary>
        /// 
        /// </summary>
        public enum FileWasDownloadedAndSavedResult
        {
            FileSuccessfullyDownloadedAndSaved,
            CouldNotDownloadFile_NoInternetConnection,
            CannotWriteToDestination,
            ErrorTryingToDownloadFile,
            TextObtained
        }

        /// <summary>
        /// 
        /// </summary>
        public enum CanSaveFileResult
        {
            FileNameIsEmpty,
            FileAlreadyExistsAndIsNotReadOnly,
            FileAlreadyExistsAndIsReadOnly,
            FileDoesNotExistAndDirectoryIsNotReadOnly,
            FileDoesNotExistAndDirectoryIsReadOnly,
            FileDoesNotExistAndCanCreateDirectory,
            FileDoesNotExistAndCannotCreateDirectory
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static CanSaveFileResult CanSaveFile(string fileName)
        {
            CanSaveFileResult result = CanSaveFileResult.FileNameIsEmpty;

            FileInfo fileInfo = new FileInfo(fileName);
            if (fileInfo.Exists)
            {
                if (fileInfo.IsReadOnly)
                    result = CanSaveFileResult.FileAlreadyExistsAndIsReadOnly;
                else
                    result = CanSaveFileResult.FileAlreadyExistsAndIsNotReadOnly;
            }
            else
            {
                string directory = fileInfo.DirectoryName;
                DirectoryInfo directoryInfo = new DirectoryInfo(fileInfo.DirectoryName);
                if (directoryInfo.Exists)
                {
                    if ((directoryInfo.Attributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
                        result = CanSaveFileResult.FileDoesNotExistAndDirectoryIsReadOnly;
                    else
                        result = CanSaveFileResult.FileDoesNotExistAndDirectoryIsNotReadOnly;
                }
                else
                {
                    try
                    {
                        result = CanSaveFileResult.FileDoesNotExistAndCanCreateDirectory;
                    }
                    catch
                    {
                        result = CanSaveFileResult.FileDoesNotExistAndCannotCreateDirectory;
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Set file attributes
        /// </summary>
        /// <param name="fileName">File whose attributes are to be set</param>
        /// <param name="setToReadOnly">Read/write status required</param>
        public static bool SetFileReadWriteAttributes(String fileName, Boolean setToReadOnly)
        {
            bool result = true;
            try
            {
                FileInfo fi = new FileInfo(fileName);
                if (fi.Exists)
                {
                    FileAttributes currAttr = File.GetAttributes(fileName);
                    if (fi.IsReadOnly)
                    {// Current file is Read only
                        if (!setToReadOnly)
                        {// Remove ReadOnly
                            currAttr = currAttr & ~FileAttributes.ReadOnly;
                            File.SetAttributes(fileName, currAttr);
                        }
                    }
                    else
                    {// Current file is not Read only
                        if (setToReadOnly)
                        {// Set to ReadOnlu
                            currAttr = currAttr | FileAttributes.ReadOnly;
                            File.SetAttributes(fileName, currAttr);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Error encountered when trying to reset file attributes");
                sb.AppendLine("File: " + fileName);
                if (setToReadOnly)
                    sb.AppendLine("Attempted to set attribute to Read Only");
                else
                    sb.AppendLine("Attempted to remove attribute Read Only");
                sb.AppendLine("");
                sb.AppendLine("Error message: " + err.Message);
                MessageBox.Show(sb.ToString());
                result = false;
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dir"></param>
        /// <returns></returns>
        public static bool CanCreateFileInDirectory(string dir)
        {
            bool canCreate = true;
            if (string.IsNullOrWhiteSpace(dir))
            {
                canCreate = false;
            }
            else
            {
                string file = Path.Combine(dir, Guid.NewGuid().ToString() + ".tmp");
                if (Directory.Exists(dir) == false)
                    Directory.CreateDirectory(dir);
                try
                {
                    using (File.Create(file)) { }
                    File.Delete(file);
                }
                catch
                {
                    canCreate = false;
                }
            }
            return canCreate;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceFileURI"></param>
        /// <param name="downloadDestinationFilename"></param>
        /// <param name="okToOverwriteExistingFile"></param>
        /// <returns></returns>
        public static FileWasDownloadedAndSavedResult DownloadFileFromInternet(string sourceFileURI, string downloadDestinationFilename, bool okToOverwriteExistingFile)
        {
            FileWasDownloadedAndSavedResult fileDownloadedSuccessfully = FileWasDownloadedAndSavedResult.ErrorTryingToDownloadFile;
            sourceFileURI = sourceFileURI.Trim();
            downloadDestinationFilename = downloadDestinationFilename.Trim();
            if (ParamaterCheck(sourceFileURI, downloadDestinationFilename))
            {
                try
                {
                    if (OnlineConnection.CanConnectOnLine())
                    {
                        if (CheckCanWriteToDestination(downloadDestinationFilename, okToOverwriteExistingFile))
                        {
                            WebClient webClient = new WebClient();
                            webClient.DownloadFile(sourceFileURI, downloadDestinationFilename);
                            fileDownloadedSuccessfully = FileWasDownloadedAndSavedResult.FileSuccessfullyDownloadedAndSaved;
                        }
                        else
                            fileDownloadedSuccessfully = FileWasDownloadedAndSavedResult.CannotWriteToDestination;
                    }
                    else
                        fileDownloadedSuccessfully = FileWasDownloadedAndSavedResult.CouldNotDownloadFile_NoInternetConnection;
                }
                catch (Exception err)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("Error trying to download file");
                    sb.AppendLine("      " + sourceFileURI);
                    sb.AppendLine("");
                    sb.AppendLine("Saving to");
                    sb.AppendLine("      " + downloadDestinationFilename);
                    sb.AppendLine("");
                    sb.AppendLine("Error message: " + err.Message);
                    MessageBox.Show(sb.ToString(), "Error");
                    fileDownloadedSuccessfully = FileWasDownloadedAndSavedResult.ErrorTryingToDownloadFile;
                }
            }
            return fileDownloadedSuccessfully;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceFileURI"></param>
        /// <param name="downloadDestinationFilename"></param>
        /// <param name="fileText"></param>
        /// <returns></returns>
        public static FileWasDownloadedAndSavedResult ReadTextFileFromInternet(string sourceFileURI, string downloadDestinationFilename, out string fileText)
        {
            fileText = null;
            FileWasDownloadedAndSavedResult textReadSuccessfully = FileWasDownloadedAndSavedResult.ErrorTryingToDownloadFile;
            sourceFileURI = sourceFileURI.Trim();
            downloadDestinationFilename = downloadDestinationFilename.Trim();
            if (ParamaterCheck(sourceFileURI, downloadDestinationFilename))
            {
                try
                {
                    if (OnlineConnection.CanConnectOnLine())
                    {

                        WebClient webClient = new WebClient();
                        textReadSuccessfully = FileWasDownloadedAndSavedResult.FileSuccessfullyDownloadedAndSaved;
                        Stream data = webClient.OpenRead(sourceFileURI);
                        using (StreamReader reader = new StreamReader(data))
                        {
                            fileText = reader.ReadToEnd();
                            textReadSuccessfully = FileWasDownloadedAndSavedResult.TextObtained;
                        }
                    }
                    else
                        textReadSuccessfully = FileWasDownloadedAndSavedResult.CouldNotDownloadFile_NoInternetConnection;
                }
                catch (Exception err)
                {
                    MessageBox.Show("Error trying to download file " + sourceFileURI + ":  " + err.Message);
                    textReadSuccessfully = FileWasDownloadedAndSavedResult.ErrorTryingToDownloadFile;
                }
            }
            return textReadSuccessfully;
        }

        private static bool ParamaterCheck(string source, string destination)
        {
            bool result = true;
            if (String.IsNullOrEmpty(source))
                MessageBox.Show("Error in ReadTextFileFromInternet: - No URL specified.");
            if (String.IsNullOrEmpty(destination))
                MessageBox.Show("Error in ReadTextFileFromInternet: - No desgtination file specified.");
            return result;
        }

        private static bool CheckCanWriteToDestination(string filename, bool okToOverwriteExistingFile)
        {
            bool checkResult = false;
            FileInfo fileInfo = new FileInfo(filename);
            if (fileInfo.Exists)
            {
                if (okToOverwriteExistingFile)
                {
                    try
                    {
                        fileInfo.Delete();
                        checkResult = true;
                    }
                    catch (Exception err)
                    {
                        string s = err.Message;
                        checkResult = false;
                    }
                }
                else
                    checkResult = false;
            }
            else
            {
                string directory = fileInfo.DirectoryName;
                DirectoryInfo directoryInfo = new DirectoryInfo(directory);
                if (directoryInfo.Exists)
                {
                    checkResult = !directoryInfo.Attributes.HasFlag(FileAttributes.ReadOnly);
                }
                else
                {
                    try
                    {
                        directoryInfo.Create();
                        checkResult = true;
                    }
                    catch (Exception err)
                    {
                        string s = err.Message;
                        checkResult = false;
                    }
                }
            }
            return checkResult;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileInfo"></param>
        /// <param name="rename"></param>
        public static void RenameFile(this FileInfo fileInfo, string rename)
        {
            if (fileInfo == null)
            {
                throw new ArgumentNullException("fileInfo", "File info to rename cannot be null");
            }
            if (string.IsNullOrEmpty(rename.Trim()))
            {
                throw new ArgumentException("New name cannot be null or blank", rename);
            }
            string newName = Path.Combine(fileInfo.DirectoryName, rename);
            if (File.Exists(newName))
                throw new ArgumentException("Cannot rename file - a file with this name already exists", rename);
            else
                fileInfo.MoveTo(newName);
            return;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="absolutepath">The path to compress</param>
        /// <param name="limit">The maximum length</param>
        /// <param name="delimiter">The character(s) to use to imply incompleteness</param>
        /// <returns></returns>
        public static string ShrinkPath(string absolutepath, int limit, string delimiter = "…")
        {
            //no path provided
            if (string.IsNullOrEmpty(absolutepath))
            {
                return "";
            }

            var name = Path.GetFileName(absolutepath);
            int namelen = name.Length;
            int pathlen = absolutepath.Length;
            var dir = absolutepath.Substring(0, pathlen - namelen);

            int delimlen = delimiter.Length;
            int idealminlen = namelen + delimlen;

            var slash = (absolutepath.IndexOf("/") > -1 ? "/" : "\\");

            //less than the minimum amt
            if (limit < ((2 * delimlen) + 1))
            {
                return "";
            }

            //fullpath
            if (limit >= pathlen)
            {
                return absolutepath;
            }

            //file name condensing
            if (limit < idealminlen)
            {
                return delimiter + name.Substring(0, (limit - (2 * delimlen))) + delimiter;
            }

            //whole name only, no folder structure shown
            if (limit == idealminlen)
            {
                return delimiter + name;
            }
            return dir.Substring(0, (limit - (idealminlen + 1))) + delimiter + slash + name;
        }
    }
}
