﻿using System;
using System.Net.NetworkInformation;
using System.Text;
using System.Net;

namespace mm.Utilities
{
    /// <summary>
    /// Class <c>OnlineConnection</c> provides a set of methods to determine if an online connection is available
    /// </summary>
    public static class OnlineConnection
    {

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static bool CanConnectToANetwork()
        {
            bool canConnectOnLine = true;
            try
            {
                if (NetworkInterface.GetIsNetworkAvailable())
                {
                    canConnectOnLine = true;
                }
            }
            catch (Exception err)
            {
                canConnectOnLine = false;
                string s1 = err.Message;
            }
            return canConnectOnLine;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static bool CanConnectOnLine()
        {
            bool canConnectOnLine = false;
            try
            {
                Ping myPing = new Ping();
                String host = "google.com";
                byte[] buffer = new byte[32];
                int timeout = 1000;
                PingOptions pingOptions = new PingOptions();
                PingReply reply = myPing.Send(host, timeout, buffer, pingOptions);
                canConnectOnLine = (reply.Status == IPStatus.Success);
            }
            catch (Exception)
            {
                canConnectOnLine = false;
            }
            return canConnectOnLine;
        }
    }

    /// <summary>
    /// Class <c>OnLineConnections</c> provides a set of methods to determine if an online connection is available
    /// </summary>
    public static class OnlineConnections
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static bool CanConnectTo(string url)
        {
            try
            {
                using (var client = new WebClient())
                {
                    using (var stream = client.OpenRead(url))
                    {
                        return true;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string GetOnlineFileContents(string url)
        {
            string result = null;
            try
            {
                using (var client = new WebClient())
                {
                    using (var stream = client.OpenRead(url))
                    {
                        var content = client.DownloadData(url);
                        result = Encoding.UTF8.GetString(content);
                    }
                }
            }
            catch
            {
            }
            return result;
        }
    }
}
