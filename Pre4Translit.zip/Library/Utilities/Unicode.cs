﻿using System;
using System.Reflection;
using System.Globalization;
using System.Windows.Forms;

namespace mm.Utilities
{
    /* ALM	U+061C	ARABIC LETTER MARK	Right-to-left zero-width Arabic character */
    /// <summary>
    /// 
    /// </summary>
    public class Unicode
    {
        /// <summary>
        /// 
        /// </summary>
        public const char Ltr_embed = '\u202A'; //8234
        /// <summary>
        /// 
        /// </summary>
        public const char Pop_Directional = '\u202C'; //8326
        /// <summary>
        /// 
        /// </summary>
        public const string ForceLTRCharactersAsUnicodeCharacterString = @"\u202A\u202C\u200E\u200F";
        /// <summary>
        /// 
        /// </summary>
        public const char LeftToRightMark = '\u200E'; //LEFT-TO-RIGHT MARK	Left-to-right zero-width character  - 8238
        /// <summary>
        /// 
        /// </summary>
        public const char RightToLeftMark = '\u200F'; //RIGHT-TO-LEFT MARK	Right-to-left zero-width non-Arabic character - 8239
        /// <summary>
        /// 
        /// </summary>
        public const string LTRDirectionalMarkers = @"\u202A\u202C\u200F\u200F";

        /// <summary>
        /// 
        /// </summary>
        public const string UnicodeHebrewBlock = @"\u0590-\u05ff";

        /// <summary>
        /// 
        /// </summary>
        public const string UnicodeGreekBlock = @"\u0370-\u03FF\u1F00-\u1FFF\u0342-\u0345\u2019";

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static bool IsDirectionMarker(Char aChar)
        {
            bool isDirectionalMarker = false;
            switch(aChar)
            {
                case LeftToRightMark:
                case RightToLeftMark:
                case Ltr_embed:
                case Pop_Directional:
                    isDirectionalMarker = true;
                    break;
            }
            return isDirectionalMarker;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static bool TextIsRightToLeft(Char aChar)
        {
            return (aChar == Ltr_embed) || (aChar == RightToLeftMark);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string TrimDirectionalCharacters(string text)
        {
            while ((text.Length > 0) && Unicode.IsDirectionMarker(text[0]))
            {
                text = text.Substring(1);
            }
            while ((text.Length > 0) && Unicode.IsDirectionMarker(text[text.Length - 1]))
            {
                text = text.Substring(0, text.Length - 1);
            }
            return text;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static int NumberOfDirectionalCharactersInString(string text)
        {
            int count = 0;
            foreach(Char aChar in text)
            {
                if (IsDirectionalControlCharacter(aChar))
                    count++;
            }
            return count;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static string RemoveAnyDirectionalMarker(string inputStr)
        {
            return inputStr.Replace(Ltr_embed.ToString(), "").Replace(Pop_Directional.ToString(), "").Replace(LeftToRightMark.ToString(),"").Replace(RightToLeftMark.ToString(), "");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static bool CharacterEmbedsLtr(Char aChar)
        {
            return aChar == Ltr_embed;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static bool CharacterPopsEmbededLtr(Char aChar)
        {
            return aChar == Pop_Directional;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static bool IsDirectionalControlCharacter(Char aChar)
        {
            return CharacterEmbedsLtr(aChar) || CharacterPopsEmbededLtr(aChar);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static int NumberOfControlCharactersInString(string inputStr)
        {
            int count = 0;
            foreach(Char aChar in inputStr)
            {
                if (IsDirectionalControlCharacter(aChar))
                    count++;
            }
            return count;
        }

        // For list of more types see http://www.unicode.org/reports/tr9/

        /// <summary>
        /// 
        /// </summary>
        public enum BiDiTypes {
            /// <summary>
            /// 
            /// </summary>
            NotKnown,
            /// <summary>
            /// 
            /// </summary>
            ParagraphSeparator,
            /// <summary>
            /// 
            /// </summary>
            LeftToRight,
            /// <summary>
            /// 
            /// </summary>
            RightToLeft,
            /// <summary>
            /// 
            /// </summary>
            OtherNeutrals,
            /// <summary>
            /// 
            /// </summary>
            WhiteSpace,
            /// <summary>
            /// 
            /// </summary>
            EuropeanNumber,
            /// <summary>
            /// 
            /// </summary>
            EuropeanNumberSeparator,
            /// <summary>
            /// 
            /// </summary>
            Other }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="aChar"></param>
        /// <returns></returns>
        public static BiDiTypes GetBiDiCategoryOfCharacter(char aChar)
        {
            BiDiTypes result = BiDiTypes.NotKnown; ;
            try
            {
                Type typeCharUnicodeInfo = Type.GetType("System.Globalization.CharUnicodeInfo");
                BindingFlags bf = BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance | BindingFlags.InvokeMethod;
                MethodInfo getBidiCategory = typeCharUnicodeInfo.GetMethod("GetBidiCategory", bf);

                Object[] parameters = new Object[2] { aChar.ToString(), 0 };
                Object o = getBidiCategory.Invoke(typeCharUnicodeInfo, bf, null, parameters, CultureInfo.InvariantCulture);
                switch(o.ToString())
                {
                    case "ParagraphSeparator":
                        result = BiDiTypes.ParagraphSeparator;
                        break;
                    case "LeftToRight":
                        result = BiDiTypes.LeftToRight;
                        break;
                    case "RightToLeft":
                        result = BiDiTypes.RightToLeft;
                        break;
                    case "OtherNeutrals":
                        result = BiDiTypes.OtherNeutrals;
                        break;
                    case "Whitespace":
                        result = BiDiTypes.WhiteSpace;
                        break;
                    case "EuropeanNumber":
                        result = BiDiTypes.EuropeanNumber;
                        break;
                    case "EuropeanNumberSeparator":
                        result = BiDiTypes.EuropeanNumberSeparator;
                        break;
                    default:
                        result = BiDiTypes.Other;
                        break;
                }
            }
            catch(Exception err)
            {
                MessageBox.Show("Error encounter when determing BiDirection of " + aChar.ToString() + "   " + err.Message, "Error");
            }
            return result;
        }
    }

}

