﻿using System.Reflection;

namespace mm.Utilities
{
    /// <summary>
    /// Class <c>ApplicationVersionNumber</c>contains methods to extract / process the applicaiton version number  
    /// </summary>
    public class ApplicationVersionNumber
    {
        /// <summary>
        ///  <value>str</value>  a dummy string
        /// </summary>
        public string str = "";

        /// <summary>
        /// Method <c>GetNow</c> returns the version number as a string
        /// </summary>
        /// <param name="accuracy">Determins the number of decimal places shown in the version number</param>
        /// <returns></returns>
        public static string GetNow(int accuracy)
        {
            string assemblyVersion = Assembly.GetExecutingAssembly().GetName().Version.ToString();
            for(int count = 0; count < 4-accuracy; count++)
                assemblyVersion = assemblyVersion.Substring(0, assemblyVersion.LastIndexOf('.'));
            return assemblyVersion;
        }
    }
}
